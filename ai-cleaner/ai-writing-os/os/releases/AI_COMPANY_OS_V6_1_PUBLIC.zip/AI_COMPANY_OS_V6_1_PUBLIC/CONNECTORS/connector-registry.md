# CONNECTOR REGISTRY

| Connector | Connected | Scopes | Read | Write | Last verified |
|---|---:|---|---:|---:|---|
| none yet | no | - | - | - | - |
