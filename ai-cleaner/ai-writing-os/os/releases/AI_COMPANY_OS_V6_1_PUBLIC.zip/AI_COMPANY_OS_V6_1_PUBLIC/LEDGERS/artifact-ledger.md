# ARTIFACT LEDGER

- Artifact ID
- Job/Project ID
- Path/name
- Version
- Created by
- Inputs
- QA status
- Replaces / replaced by
