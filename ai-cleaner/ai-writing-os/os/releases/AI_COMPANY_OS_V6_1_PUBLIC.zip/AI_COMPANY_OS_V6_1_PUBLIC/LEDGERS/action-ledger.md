# ACTION LEDGER

외부 side effect 기록.

- Action ID
- Job ID
- Action type
- Target
- Approval class
- Idempotency key
- Status: PLANNED/APPROVED/ATTEMPTED/VERIFIED/FAILED/UNKNOWN
- Receipt reference
