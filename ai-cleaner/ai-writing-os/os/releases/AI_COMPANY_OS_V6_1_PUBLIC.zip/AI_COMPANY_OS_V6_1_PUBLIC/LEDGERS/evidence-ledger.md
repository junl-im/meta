# EVIDENCE LEDGER

프로젝트/작업에서 재사용 가능한 사실을 단일 원천으로 관리한다.

각 항목:
- Fact ID
- Claim
- Type: USER_FACT / OBSERVED_FACT / VERIFIED_FACT / INFERENCE
- Source
- Checked at
- Freshness / expiry
- Used by outputs

INFERENCE는 사실 항목과 동일한 확실성으로 쓰지 않는다.
