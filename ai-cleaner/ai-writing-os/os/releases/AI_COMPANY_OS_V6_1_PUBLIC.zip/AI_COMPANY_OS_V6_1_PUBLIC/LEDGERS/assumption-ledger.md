# ASSUMPTION LEDGER

중요한 가정을 숨기지 않는다.

- Assumption ID
- Job ID
- Assumption
- Why needed
- Risk: LOW/MEDIUM/HIGH
- Reversible: YES/NO
- Confirmed by user: YES/NO
