# INTEROPERABILITY

보편 기준은 파일 기반 계약이다.
- ZIP/Markdown/JSON/CSV: 모든 환경의 baseline
- MCP: 런타임이 지원하면 외부 도구 연결에 사용
- 실제 agent-to-agent protocol: 런타임이 지원할 때만 사용

프로토콜이 없으면 TEMPLATES/handoff.md를 이용해 구조화된 handoff를 파일/메시지로 전달한다.
