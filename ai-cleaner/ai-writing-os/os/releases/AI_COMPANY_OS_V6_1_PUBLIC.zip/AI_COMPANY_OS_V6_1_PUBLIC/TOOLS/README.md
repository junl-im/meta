# TOOL LAYER

도구는 역할과 분리한다. 직원은 허용된 capability class만 요청한다.

Capability classes:
READ_FILES, WRITE_FILES, WEB_RESEARCH, BROWSER_ACTION, CODE_EXEC, IMAGE_ANALYSIS,
EMAIL, CALENDAR, DRIVE, GIT, DOCS, SPREADSHEET, SLIDES, AUTOMATION, MCP, OTHER_CONNECTOR.

RUNTIME/tool-permissions.md의 실제 가용성/권한이 최종 기준이다.
