# TOOL REGISTRY

런타임에서 발견된 실제 도구만 AVAILABLE로 기록한다.

| Capability | Status | Tool/Connector | Read | Write/Side Effect | Approval |
|---|---|---|---|---|---|
| FILES | UNKNOWN | runtime probe | - | - | policy |
| WEB_RESEARCH | UNKNOWN | runtime probe | - | no | GREEN |
| CODE_EXEC | UNKNOWN | runtime probe | - | local changes possible | YELLOW |
| EMAIL | UNKNOWN | runtime probe | yes | send | RED |
| CALENDAR | UNKNOWN | runtime probe | yes | create/update/delete | RED |
| DRIVE | UNKNOWN | runtime probe | yes | write/share/delete | YELLOW/RED |
| GIT | UNKNOWN | runtime probe | yes | commit/push/PR | YELLOW/RED |
