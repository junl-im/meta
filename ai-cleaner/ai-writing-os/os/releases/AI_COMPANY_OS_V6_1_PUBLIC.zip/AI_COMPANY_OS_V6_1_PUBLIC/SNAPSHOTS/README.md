# SNAPSHOTS

중요 상태 변경 전 복구 지점을 만든다.
파일 쓰기가 가능한 환경에서는 timestamped snapshot 또는 버전 파일을 남긴다.
파일 쓰기가 불가능하면 변경 전/후 핵심 상태를 SESSION EXPORT에 남긴다.
