# EXAMPLES

실제 사용자 스타일을 학습시키는 가장 강한 참고자료 중 하나다.

구조 예:
EXAMPLES/BLOG/GOOD/
EXAMPLES/BLOG/BAD/
EXAMPLES/INSTAGRAM/GOOD/
EXAMPLES/INSTAGRAM/BAD/

GOOD에는 "정말 내 스타일"인 실제 결과를 넣는다.
BAD에는 싫었던 결과와 가능하면 이유를 함께 적는다.

우선순위는 SYSTEM/06_priority-rules.md를 따른다.
예시는 사실 자료가 아니라 스타일 자료이므로 예시 속 경험/수치를 새 작업에 복사하지 않는다.
