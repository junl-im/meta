# INSTAGRAM GOOD EXAMPLES

마음에 든 릴스 자막, 피드 글, 후기형 게시물을 넣는다.
REELS/FEED/REVIEW가 섞이면 파일명으로 구분한다.
