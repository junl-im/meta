# INSTAGRAM BAD EXAMPLES

싫었던 인스타 결과와 이유를 넣는다.
예:
- 한 줄이 너무 김
- CTA가 매번 같음
- 자극적인데 내용이 약함
- 이모지가 과함
