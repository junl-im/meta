# KNOWLEDGE BASE

프로젝트와 무관하게 재사용 가치가 있는 검증된 지식/브랜드 정보/제품 정의를 저장한다.
개인 선호는 MEMORY, 현재 프로젝트 상태는 PROJECTS, 원본 자료는 ASSETS에 둔다.
