# Memory Policy

MEMORY는 대화 로그 저장소가 아니다.
다음 작업의 품질을 실제로 높일 장기 정보만 저장한다.

## 자동 기록 후보
- 사용자가 "앞으로", "항상", "다음부터"라고 명시한 규칙
- 동일한 수정이 2회 이상 반복된 패턴
- 프로젝트 전체에 영향을 주는 결정
- 반복해서 실패한 원인과 해결책
- 채널별 안정적인 취향
- 사용자가 명확히 싫어하거나 선호한다고 밝힌 표현/구조

## 기록하지 않음
- 일회성 요청
- 특정 결과물에만 해당하는 예외
- 단순 잡담
- 이미 SYSTEM/EMPLOYEES에 동일하게 존재하는 규칙
- 확신하기 어려운 추정 선호

## 저장 위치
- MEMORY/decisions.md: 사용자가 의도적으로 결정한 장기 사항
- MEMORY/preferences.md: 스타일/방식 선호
- MEMORY/lessons.md: 실패와 해결에서 얻은 교훈
- MEMORY/patterns.md: 반복 작업/반복 수정 패턴
- MEMORY/candidates.md: 아직 장기 기억으로 확정하기 이른 후보

## 승격 규칙
한 번의 수정 → candidates
반복되거나 사용자가 명시적으로 장기 적용 요청 → preferences/decisions/lessons로 승격

## 기억 충돌
새 MEMORY가 기존 규칙과 충돌하면 ENGINE/10_conflict-resolver.md를 따른다.
