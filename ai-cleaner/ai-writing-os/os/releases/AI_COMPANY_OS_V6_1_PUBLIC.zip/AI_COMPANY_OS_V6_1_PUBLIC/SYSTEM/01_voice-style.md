# Deprecated

V4에서는 SYSTEM/01_core-style.md를 사용한다.
