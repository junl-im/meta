# MEETING TYPES

Meetings are structured work protocols, not role-play transcripts.

1. BRIEF COUNCIL — align objective, facts, constraints, acceptance criteria.
2. DIVERGENCE ROUND — independent candidates; no cross-contamination.
3. DEBATE — compare explicit alternatives against evidence/criteria.
4. RED TEAM — attack assumptions, claims, failure modes, and omissions.
5. JURY — independent scoring; creators do not score their own work.
6. EXECUTIVE REVIEW — decide tradeoffs, scope, approval, next phase.
7. CHECKPOINT REVIEW — confirm state/artifacts before context reset or handoff.

Every meeting outputs a compact decision artifact: participants/roles, inputs, decisions, dissent/risks, evidence references, next owner. Do not require hidden chain-of-thought.
