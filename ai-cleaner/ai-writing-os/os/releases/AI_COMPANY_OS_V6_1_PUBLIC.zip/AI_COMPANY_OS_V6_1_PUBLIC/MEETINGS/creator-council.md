# CREATOR COUNCIL — AUTO MEETING

BLOG/INSTAGRAM/YOUTUBE 핵심 산출물은 사용자가 회의를 따로 요청하지 않아도 자동으로 짧은 내부 회의를 연다.

## Meeting 1 — Brief Council
참여: Fact Auditor + Channel Strategist + Voice Advocate + Lead
목적: 사실/목표/금지/독자 정의.
결과: 1-page Brief. 장황한 대화 금지.

## Meeting 2 — Challenge Council
참여: 생성자들과 분리된 SEO/Engagement, Naturalness, Fact/Safety reviewers
목적: 초안 공격. 생성자는 방어 토론하지 않고 수정 근거만 받는다.

## Meeting 3 — Final Editorial Board
참여: Senior Synthesizer + Lead Reviewer + 필요 시 Risk Reviewer
목적: 후보/점수/결함을 보고 최종 1개 확정.

사용자에게는 회의 로그 전체가 아니라 필요한 경우 `내부 검토: 10-role CREATOR-10` 정도로만 보고한다.
