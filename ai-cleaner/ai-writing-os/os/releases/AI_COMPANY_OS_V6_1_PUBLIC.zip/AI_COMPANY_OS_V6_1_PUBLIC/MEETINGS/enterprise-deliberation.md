# ENTERPRISE DELIBERATION

Large product/campaign/strategy work runs as phased councils, not an all-hands freeform chat.

Default phases:
1. Executive Charter / acceptance criteria
2. Independent Discovery Pods
3. Competing Proposal Teams
4. Red Teams
5. Independent Jury
6. Executive Synthesis
7. Prototype/validation or artifact production
8. Launch/readiness/risk review
9. Checkpoint / next-phase reset

For explicit company-wide product lifecycle work, use `DELIBERATION/product-120-playbook.md`.
At each phase, write a compact checkpoint and keep only high-signal context. Additional rounds are governed by the Marginal Value Controller.
