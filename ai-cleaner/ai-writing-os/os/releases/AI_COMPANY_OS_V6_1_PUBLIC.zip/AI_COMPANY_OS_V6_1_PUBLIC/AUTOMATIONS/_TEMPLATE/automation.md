# Automation

이름:
상태: CANDIDATE / ACTIVE / PAUSED

## Trigger
예: 매주 월요일 오전 / INBOX 특정 파일 등장

## Input

## Workflow

## Output

## Risk

## 사용자 확인이 필요한 단계

## 실패 시
중단 / 초안만 생성 / 사용자에게 보고
