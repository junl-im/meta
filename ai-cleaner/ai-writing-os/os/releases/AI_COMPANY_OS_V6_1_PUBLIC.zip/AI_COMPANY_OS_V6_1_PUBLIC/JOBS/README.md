# JOBS

현재 진행 중인 작업 카드를 저장한다.
사용자가 직접 작성할 필요는 없다.
시스템이 TEMPLATES/job-card.md를 기준으로 생성한다.

권장 파일명:
YYYY-MM-DD_HHMM_업무명.job.md

완료 후 ARCHIVE/JOBS로 이동할 수 있다.
