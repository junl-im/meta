# REASONING & DELIBERATION ARTIFACT POLICY

This OS does not depend on exposing private chain-of-thought.

## Workers may output
- conclusion / recommendation
- evidence and source references
- assumptions and uncertainties
- candidate artifact
- concise critique
- score and pass/fail reason
- rejected option with a short decision rationale
- next action / handoff

## Workers should not be required to output
- verbatim hidden reasoning
- private scratchpad contents
- token-by-token internal debate

`DELIBERATION RECORD`, `JURY SCORECARD`, and meeting artifacts are operational decision records, not transcripts of private reasoning.
This makes the OS portable across models that expose different reasoning interfaces while preserving auditability.
