# AUDIT POLICY

중요 작업은 다음을 남긴다.
- Request
- Job/Project ID
- Active roles
- Sources / files used
- Key assumptions
- Decisions
- Checks performed
- Output
- Limitations

단순 작업은 로그를 과도하게 만들지 않는다.
