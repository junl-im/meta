# COMPANY DASHBOARD

## Active Projects
- 없음

## Queue
- 없음

## Blocked
- 없음

## Awaiting Human Approval
- 없음

## Recent Deliveries
- 없음

## Memory Candidates
- 없음

## Repeated Work / Automation Candidates
- 없음
