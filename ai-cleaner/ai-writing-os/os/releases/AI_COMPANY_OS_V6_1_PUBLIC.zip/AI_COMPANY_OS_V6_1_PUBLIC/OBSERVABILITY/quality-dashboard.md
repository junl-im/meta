# QUALITY / DELIBERATION DASHBOARD

Per Job/Project, track when available:
- quality floor selected
- planned vs completed role-contributions
- distinct roles / distinct lenses
- candidate count
- red-team critical/major findings
- jury score before vs after synthesis
- self-revision rounds
- evidence coverage / stale facts
- approval/side-effect status
- runtime reality level
- degraded-mode reason
- final artifact / receipt status

Purpose: make extra staffing measurable. `10 roles` is not success by itself; improvement in quality, coverage, or risk reduction is the objective.
