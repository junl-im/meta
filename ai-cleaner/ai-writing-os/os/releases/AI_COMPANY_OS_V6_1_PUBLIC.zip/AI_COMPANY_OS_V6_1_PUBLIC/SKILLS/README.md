# SHARED SKILLS LIBRARY

직원은 페르소나가 아니라 `역할 + 스킬 번들 + 권한 + 산출물 계약`이다.
공용 기술은 직원 파일에 중복 작성하지 않고 registry에서 참조한다.

SKILLS/skill-registry.md에서 필요한 기술만 선택한다.
