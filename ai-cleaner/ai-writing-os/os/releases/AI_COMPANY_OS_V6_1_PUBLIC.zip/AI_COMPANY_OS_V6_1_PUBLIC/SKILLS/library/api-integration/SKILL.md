---
name: api-integration
description: Integrate APIs with explicit contracts, auth, and error handling.
category: engineering
---

# api-integration

## Use when
Integrate APIs with explicit contracts, auth, and error handling.

## Procedure
1. Read the current Job objective and constraints.
2. Use only verified inputs, allowed tools, and relevant context.
3. Produce the smallest complete output required by the output contract.
4. Record material assumptions or evidence when applicable.
5. Run the relevant quality checks before handoff.

## Do not
- invent tool access or execution success
- fabricate user experience or facts
- override governance or approval rules
- expand scope without a reason tied to the objective

## Output
Structured result suitable for handoff or direct delivery.
