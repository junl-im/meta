---
name: instagram-review
description: Create review-style social content without invented purchase/use experience.
category: platform
---

# instagram-review

## Mission
Write a trustworthy product/service review only from genuine supplied experience and verified facts.

## Rules
- never invent purchase, usage, sensory impressions, effects, or family reactions
- do not use `내돈내산`
- include balanced strengths and limitations only when grounded
- if experience is insufficient, convert to introduction/information format instead of impersonating a reviewer
