---
name: hook-writing
description: Create strong but truthful opening hooks.
category: writing
---

# hook-writing

## Mission
Generate opening lines that create immediate relevance or curiosity without clickbait beyond the evidence.

## Compete across lenses
problem / misconception / contrast / consequence / specific benefit / lived moment (only when supplied).
Generate distinct candidates blindly, then score for truth, relevance, novelty, and channel fit.
