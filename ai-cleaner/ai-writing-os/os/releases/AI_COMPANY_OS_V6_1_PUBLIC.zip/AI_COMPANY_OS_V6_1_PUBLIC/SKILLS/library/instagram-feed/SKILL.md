---
name: instagram-feed
description: Create readable feed posts with useful detail and participation prompts.
category: platform
---

# instagram-feed

## Mission
Turn a topic into a save-worthy, searchable Instagram feed caption rather than copying the Reel.

## Procedure
Use a strong natural opening, add concrete context/details, use actual experience only when supplied, create readable mobile breaks, and use one purposeful engagement CTA. Add about 7-10 relevant hashtags when useful; never label them as trending without verification.
