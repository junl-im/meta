---
name: customer-voice
description: Extract authentic customer language, needs, objections, and desired outcomes from evidence.
category: customer
---

# customer-voice

## Mission
Extract authentic customer language, needs, objections, and desired outcomes from evidence.

## Procedure
1. Read the current objective, constraints, facts, and output contract.
2. Identify the decision or artifact this skill is responsible for.
3. Separate evidence from assumptions and mark unknowns that materially change the result.
4. Produce a compact specialist output for the next role or final deliverable.
5. Apply relevant quality and escalation rules before handoff.

## Do not
- fabricate facts, user experience, tool access, or execution success
- duplicate another role's work without a deliberate competition objective
- override current user instructions, governance, or approval gates

## Output
A concise specialist artifact with findings, recommendations, evidence/assumptions, and handoff-ready next actions.
