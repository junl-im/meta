---
name: source-quality
description: Assess source authority, freshness, independence, and relevance.
category: research
---

# source-quality

## Mission
Judge whether a source is fit for the specific claim.

Rank sources by directness, authority, recency, independence, methodology, and conflict of interest. Prefer primary sources for specs/rules/official claims; use reputable secondary sources for context and competing interpretations. Flag circular citations and marketing claims masquerading as evidence.
