---
name: workforce-planning
description: Choose the smallest useful team for a job.
category: orchestration
---

# workforce-planning

## Mission
Allocate enough distinct expertise to raise quality without cloning identical work.

Use the Quality Floor, Complexity, risk, parallelizability, and marginal-value rules. Assign each contribution a unique responsibility or deliberate competing lens. Separate generators from evaluators. For long projects, staff by phase and write checkpoints rather than keeping every role active simultaneously.
