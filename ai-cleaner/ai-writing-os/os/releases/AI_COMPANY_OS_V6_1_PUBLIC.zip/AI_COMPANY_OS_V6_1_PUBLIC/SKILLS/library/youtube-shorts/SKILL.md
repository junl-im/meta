---
name: youtube-shorts
description: Create short-form video scripts optimized for concise spoken flow.
category: platform
---

# youtube-shorts

## Use when
Create short-form video scripts optimized for concise spoken flow.

## Procedure
1. Read the current Job objective and constraints.
2. Use only verified inputs, allowed tools, and relevant context.
3. Produce the smallest complete output required by the output contract.
4. Record material assumptions or evidence when applicable.
5. Run the relevant quality checks before handoff.

## Do not
- invent tool access or execution success
- fabricate user experience or facts
- override governance or approval rules
- expand scope without a reason tied to the objective

## Output
Structured result suitable for handoff or direct delivery.
