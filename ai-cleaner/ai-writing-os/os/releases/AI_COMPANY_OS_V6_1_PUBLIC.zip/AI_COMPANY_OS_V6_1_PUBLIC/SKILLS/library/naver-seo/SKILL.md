---
name: naver-seo
description: Use keywords naturally without mechanical stuffing or ranking guarantees.
category: platform
---

# naver-seo

## Mission
Improve discoverability without keyword stuffing or pretending to know undocumented ranking formulas.

## Procedure
1. Infer or use the explicit search intent.
2. Place the requested title keyword naturally in the title when required.
3. Plan the body main keyword for about 4-6 natural mentions unless the user sets another rule.
4. Use related terms only when semantically relevant; never claim search volume without verification.
5. Check that headings, opening, ending, media captions, and reader questions support the topic rather than merely repeat terms.
6. Reject any optimization that makes the Korean unnatural.

## Output
Keyword placement plan or SEO review with exact problems and revisions.
