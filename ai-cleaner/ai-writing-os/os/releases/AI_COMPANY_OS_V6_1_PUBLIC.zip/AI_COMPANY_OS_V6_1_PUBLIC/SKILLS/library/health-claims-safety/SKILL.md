---
name: health-claims-safety
description: Avoid unsupported medical/health efficacy claims.
category: risk
---

# health-claims-safety

## Mission
Prevent unsupported medical or health-benefit claims in content.

Avoid treatment/cure/prevention certainty, distinguish personal experience from general effect, verify material safety/use claims from appropriate authoritative evidence, and soften or omit claims that cannot be supported. Marketing goals never override this rule.
