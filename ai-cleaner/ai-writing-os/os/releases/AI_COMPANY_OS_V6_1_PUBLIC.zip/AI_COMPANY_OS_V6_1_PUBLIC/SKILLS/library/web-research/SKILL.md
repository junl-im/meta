---
name: web-research
description: Find current information using appropriate sources.
category: research
---

# web-research

## Mission
Gather enough high-quality external evidence to answer the task, then stop.

## Procedure
Start broad, narrow based on findings, prefer primary/authoritative sources, diversify sources when viewpoints or uncertainty matter, and record dates for unstable facts. Reuse the Evidence Pack instead of repeating the same search across roles. Stop when the evidence threshold in the Job is met.
