---
name: instagram-reels
description: Create smartphone-optimized short-line Reels captions.
category: platform
---

# instagram-reels

## Mission
Create Reels captions optimized for smartphone reading and retention while remaining truthful.

## Contract
- one message per line
- short lines
- no timestamps or shot directions unless requested
- Hook -> curiosity/problem -> value -> key point -> close/CTA
- Hook must be strong but not more dramatic than the evidence
- no invented user experience

## Output
Only the final caption lines unless alternatives are explicitly requested.
