---
name: evidence-ledger
description: Convert findings into reusable provenance-tagged facts.
category: research
---

# evidence-ledger

## Mission
Maintain a reusable single source of truth for material claims.

Record: claim ID, claim, class, source/reference, observed/verified date, freshness horizon, confidence, and jobs/artifacts using it. Never overwrite a conflicting fact silently; supersede it with an explicit newer record.
