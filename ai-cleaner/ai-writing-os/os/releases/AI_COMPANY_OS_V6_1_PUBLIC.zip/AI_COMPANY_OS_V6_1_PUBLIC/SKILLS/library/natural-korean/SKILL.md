---
name: natural-korean
description: Write fluent Korean without translation-like or generic AI phrasing.
category: writing
---

# natural-korean

## Mission
Make Korean read like a real person wrote it, preserving the user's channel voice.

## Checks
- vary sentence length and endings
- remove translation-like syntax and stock AI transitions
- avoid repetitive `그래서/하지만/또한` patterns
- avoid unsupported superlatives and generic filler
- preserve useful colloquial rhythm without forcing slang or emoticons
- read the passage as spoken Korean; rewrite anything technically correct but socially unnatural

## Output
Revised text plus only the minimum notes needed for downstream editors.
