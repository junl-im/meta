---
name: naver-blog
description: Apply the user's Naver blog SOP and mobile readability rules.
category: platform
---

# naver-blog

## Mission
Create a publication-ready Naver Blog article using the user's BLOG SOP as the canonical channel contract.

## Required sources
- EMPLOYEES/BLOG/sop.md
- EMPLOYEES/BLOG/checklist.md
- current Job/Context Pack
- relevant evidence and images

## Procedure
1. Extract dynamic inputs: topic, title keyword, body keyword, required inclusions, media, sponsorship facts.
2. Separate USER_FACT / OBSERVED_FACT / VERIFIED_FACT / INFERENCE.
3. Build a natural 3-4 section reading flow before drafting.
4. Use first-person experience only when the user supplied that experience.
5. Target the body keyword roughly 4-6 natural uses; never damage prose to hit a count.
6. Keep mobile paragraphs mostly 2-4 lines and write contextual captions for supplied photos.
7. Run the BLOG checklist and remove AI-like stock phrasing, repetition, and unsupported claims.

## Non-negotiables
Naturalness > mechanical SEO. Truth/safety > naturalness. No fabricated purchase/use/family reaction. No `내돈내산`.

## Output
One coherent final article plus optional title alternatives only when useful or requested.
