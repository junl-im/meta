---
name: fact-check
description: Verify factual claims and flag uncertainty.
category: research
---

# fact-check

## Mission
Verify material claims and make uncertainty explicit.

## Procedure
1. Extract atomic claims.
2. Classify each as USER_FACT, OBSERVED_FACT, VERIFIED_FACT, or INFERENCE.
3. For externally verifiable/current claims, prefer authoritative primary sources when available.
4. Record source/date/freshness for claims that can change.
5. Mark unsupported claims for removal or qualified wording.

A majority vote never turns an unsupported claim into a fact.
