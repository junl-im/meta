# Conflict Resolver

## 충돌 해결 순서
1. 현재 사용자의 명시 지시
2. 안전/사실성 필수 규칙
3. 현재 JOB의 확정 정보
4. 최신 PROJECT 결정
5. 최신 장기 MEMORY
6. 직원 SOP
7. 과거 EXAMPLES

## 예외
사용자의 현재 지시가 허위 사실 생성이나 안전 문제를 요구하면 그대로 따르지 않는다.

## 기록
장기 규칙이 바뀐 경우 기존 MEMORY를 조용히 중복 추가하지 않는다.
변경 날짜와 새 기준을 decisions/preferences에 반영한다.
