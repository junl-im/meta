# Project Controller

JOB 1개를 넘어서는 경우 PROJECT를 만든다.
PROJECT는 Objective / Scope / Non-goals / Deliverables / Jobs / Dependencies / Decisions / Risks / Status / Next Action을 가진다.

단순 블로그 글 1건을 불필요하게 프로젝트화하지 않는다.
