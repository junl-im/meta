# Capability Router

업무를 `역할`과 `기능`으로 분리한다.
예: Naver Blog Writer는 직원이고, fact-check / natural-korean / photo-caption은 Skills다.
직원 프로필을 길게 복제하지 말고 공용 SKILLS를 참조한다.
현재 플랫폼 고유 도구가 있으면 ADAPTERS를 통해 연결한다.
