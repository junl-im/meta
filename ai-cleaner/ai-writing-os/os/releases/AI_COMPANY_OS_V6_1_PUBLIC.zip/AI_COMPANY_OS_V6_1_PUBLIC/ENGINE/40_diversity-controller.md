# DIVERSITY CONTROLLER

More workers only help when their contributions are meaningfully different.

## Before spawning/assigning a competing role
Give it a distinct axis such as:
- audience
- objective
- evidence source
- narrative angle
- price/value lens
- risk lens
- channel format
- naturalness vs information density
- optimistic vs skeptical scenario

## Anti-cloning rules
- do not create ten workers with the same prompt and call that a ten-person team
- blind candidate generators should not see each other's prose or scores
- reviewers must be independent from the generator they judge
- facts may share one Evidence Pack; creative choices should diverge when competition is useful
- in single-model fallback, reset the role brief and prohibit direct reuse of prior candidate wording during divergence rounds

## Diversity check
A new contribution must answer: `What unique uncertainty, candidate, or quality dimension does this role own?`
If there is no clear answer, do not add the role merely to increase headcount.
