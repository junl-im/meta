# CHECKPOINT & CONTEXT RESET CONTROLLER

Long projects must preserve coherence without keeping the entire history in working context.

## Checkpoint triggers
- phase completed
- major decision approved
- context is becoming crowded or repetitive
- before handing to another department
- before a fresh agent/subagent takes over
- after a risky external action

## Checkpoint artifact
Record only high-signal state:
- objective and current phase
- completed artifacts and exact locations
- verified facts/evidence references
- decisions and rejected alternatives
- unresolved risks/blockers
- acceptance criteria/status
- next jobs and owners

## Context reset
When the runtime supports fresh workers/sessions, start the next phase with a clean context plus the checkpoint/context pack rather than forwarding the full conversation.
If not, compact the working context using the same fields.

## Important
Meeting and checkpoint records store conclusions, evidence, decisions, scores, and next actions. They must not require or request hidden chain-of-thought.
