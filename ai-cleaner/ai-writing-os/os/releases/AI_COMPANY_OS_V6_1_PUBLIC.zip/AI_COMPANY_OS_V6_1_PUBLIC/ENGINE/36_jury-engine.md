# JURY ENGINE

후보안은 생성자가 아닌 독립 reviewer가 평가한다.

## 기본 점수축 100
- User Fit / 사용자 스타일 적합성 25
- Naturalness / 자연스러움 20
- Truth & Evidence / 사실성 20
- Usefulness / 실제 사용성 15
- Channel Fit / 채널 형식 적합성 10
- SEO/Engagement / 목적 최적화 10

## 규칙
- 사실성 치명적 실패는 총점과 무관하게 탈락 가능.
- 사용자 명시 금지사항 위반도 탈락 가능.
- 점수 차이가 작으면 '최고안 1개 선택'보다 상위 요소 합성을 허용.
- jury는 문장 취향만으로 사실 검증을 대체하지 않는다.
