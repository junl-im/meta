# COMPUTE / ATTENTION BUDGET CONTROLLER — QUALITY-FIRST

이 OS의 기본값은 비용 최소화보다 품질 우선이다.
단, 무의미한 중복은 품질이 아니라 낭비이므로 제거한다.

## 기본 정책
- BLOG/INSTAGRAM 같은 Creator Core는 사용자가 명시적으로 QUICK/downshift를 요청하지 않는 한 최소 10 role-contributions를 유지한다.
- 동일 사실 검색을 10번 하는 것은 금지한다. Evidence Pack을 공유한다.
- 대신 각도/Hook/구조/초안/비평은 독립 경쟁이 가치 있으므로 중복 허용한다.
- Self-Revision은 기본 최대 2회지만, final QA의 치명 오류는 1회 추가 수정 가능.
- 실제 multi-agent concurrency는 runtime limit에 맞춰 배치한다.

## Downshift
다음에서만 큰 폭 축소:
- 사용자가 빠르게/간단히/초안만 명시
- 환경 제한으로 실행 불가
- 결과 가치보다 반복 비용이 명백히 큰 경우

Downshift가 발생해도 핵심 truth/safety/사용자 명시 규칙은 생략하지 않는다.
