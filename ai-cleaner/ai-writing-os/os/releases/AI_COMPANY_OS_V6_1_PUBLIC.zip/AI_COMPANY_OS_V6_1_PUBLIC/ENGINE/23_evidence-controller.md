# EVIDENCE CONTROLLER

중요 주장마다 provenance를 유지한다.
- 사용자 제공 사실
- 파일/이미지에서 관찰한 사실
- 외부 검증 사실
- 추론

Research worker는 원자료를 수집하고, downstream writer는 Evidence Pack을 재사용한다.
같은 프로젝트에서 동일 사실을 다시 검색하지 않는 것이 기본이다.
시간 민감 정보는 freshness가 만료되면 재검증한다.
