# CONCURRENCY CONTROLLER

병렬화는 독립적인 작업에만 사용한다.
공유 상태를 쓰는 두 작업은 동시에 수정하지 않는다.

기본 제한:
- 단순 요청: 1 active worker
- 중간 프로젝트: 2~4 active workers
- 대형 조사/캠페인: 5~8 active workers
- 8개 초과는 명확한 가치 근거가 있어야 한다.

런타임의 실제 concurrency limit가 더 낮으면 그 값을 따른다.
각 worker는 별도 산출물/출력 키를 사용하고 Manager가 gather한다.
