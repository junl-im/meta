# COMPETITION ENGINE

품질을 높일 가치가 있는 산출물은 최소 2개 이상의 독립 후보를 만든다.

## Blind Divergence
후보 생성자는 다음만 공유한다.
- 동일한 User Facts / Observed Facts / Verified Facts
- 동일한 사용자 제약
- 동일한 channel SOP

공유하지 않는다.
- 다른 후보의 문장
- 다른 후보의 점수
- jury의 선호

## Competition Types
- ANGLE COMPETITION: 어떤 관점/스토리라인이 좋은가
- HOOK COMPETITION: 어떤 첫 문장이 강한가
- STRUCTURE COMPETITION: 어떤 순서가 읽기 좋은가
- DRAFT COMPETITION: 전체 산출물 후보
- CTA COMPETITION: 어떤 행동 유도가 자연스러운가

모든 작업에서 모든 경쟁을 다 하지 않는다. 채널 playbook이 지정한 경쟁을 우선한다.
