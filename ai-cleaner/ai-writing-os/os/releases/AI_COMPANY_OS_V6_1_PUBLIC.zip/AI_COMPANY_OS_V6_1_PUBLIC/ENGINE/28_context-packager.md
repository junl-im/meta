# CONTEXT PACKAGER

가장 중요한 운영 엔진 중 하나다.

작업마다 `Context Pack`을 만들어 필요한 정보만 전달한다.
포함 순서:
1. 현재 사용자 요청 + 확정된 Content Scope + Output Language
2. Job/Project objective + constraints
3. 관련 USER FACT / decisions
4. 선택된 Employee Card
5. 필요한 Skills
6. Evidence Pack
7. 관련 GOOD/BAD examples 최소량
8. output contract

제외:
- 관련 없는 부서/직원
- 오래된 작업 로그 전체
- 중복된 조사 원문
- 현재 Job과 무관한 memory

목표: 조직이 커질수록 context가 커지는 역설을 방지한다.


## Boundary fields — 필수
모든 Context Pack에는 최소한 다음을 명시한다.
- CONTROL_ASSETS: 규칙으로만 사용, 콘텐츠 소재 금지
- TASK_CONTENT: 현재 작업에 실제로 쓸 주제/사실/자료
- STYLE_REFERENCES: 문체만 참고, 사실 도용 금지
- PRIOR_OUTPUT_REUSE: YES/NO
- OUTPUT_LANGUAGE: 기본 `ko`, 명시 지시가 있을 때만 변경

이 필드가 없으면 OS 내용이나 영어 원문이 산출물에 새는 위험이 있으므로 완전한 Context Pack으로 보지 않는다.
