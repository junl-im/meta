# Workflow Builder

## Preflight
작업 흐름을 만들기 전에 반드시:
1. ENGINE/42_content-boundary-controller.md로 OS/규칙과 실제 콘텐츠를 분리
2. ENGINE/43_language-router.md로 출력 언어를 결정


## 단일 직원 원칙
업무가 명확하면 바로 담당 직원에게 보낸다.
중간 관리자 역할을 불필요하게 추가하지 않는다.

## CONTENT를 먼저 쓰는 경우
- 채널이 2개 이상이고 공통 메시지 설계가 필요
- 캠페인/런칭/시리즈 방향이 필요
- 사용자가 결과보다 아이디어와 전략을 먼저 원함
- 어떤 채널이 적합한지부터 판단해야 함

## 병렬 가능
같은 VERIFIED FACT와 핵심 메시지를 공유할 수 있는 경우 BLOG/INSTAGRAM/YOUTUBE 산출물은 공통 브리프 이후 병렬 처리 가능하다.

## Handoff
직원 간 전달 시 TEMPLATES/handoff.md 형식을 사용한다.
핵심 사실, 금지사항, 사용자 경험, 이미 결정한 메시지를 다시 해석해 왜곡하지 않는다.

## 복합 예시
"제품 콘텐츠 전체":
CONTENT → 공통 브리프 → BLOG + INSTAGRAM + YOUTUBE → 필요 시 DESIGN → 통합 QUALITY GATE

"블로그를 릴스로":
기존 BLOG OUTPUT → REUSE ENGINE → INSTAGRAM/REELS → QUALITY GATE
