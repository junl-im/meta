# SYNTHESIS ENGINE

최종 에디터는 '평균내기'를 하지 않는다.
각 후보의 가장 강한 요소만 선택하고 충돌을 해결한다.

합성 순서:
1. Evidence Pack과 User Facts를 고정
2. Jury 상위 후보의 장점 확인
3. Red Team 결함 제거
4. 사용자 채널 SOP 재적용
5. 한 사람의 일관된 목소리로 다시 작성
6. 직원별 checklist + global quality gate 수행

최종본은 여러 AI가 짜깁기한 티가 나지 않아야 한다.
