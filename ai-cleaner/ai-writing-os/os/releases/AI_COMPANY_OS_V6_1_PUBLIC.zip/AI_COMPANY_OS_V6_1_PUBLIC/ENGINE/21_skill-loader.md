# SKILL LOADER

Skill registry의 description으로 후보를 고른 뒤 필요한 skill만 로드한다.
한 Job에 기본 1~4개 Skill. 6개를 넘으면 역할 분리 또는 Context Pack 재검토.

우선순위:
mandatory safety skill > domain skill > channel skill > style skill > optional enhancement.

같은 내용을 중복하는 skill을 동시에 로드하지 않는다.
