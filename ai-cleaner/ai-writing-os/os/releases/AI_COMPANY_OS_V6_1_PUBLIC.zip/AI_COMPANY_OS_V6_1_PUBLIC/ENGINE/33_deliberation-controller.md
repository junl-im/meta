# DELIBERATION CONTROLLER

요청을 받은 뒤 Complexity와 별개로 Quality Floor를 결정한다.

## Quality Floors
- QUICK: 1~3 role-contributions. 사용자가 빠른 답/초안을 명시한 경우.
- STANDARD+: 5~7 role-contributions. 일반 전문 업무의 기본 하한.
- CREATOR-10: 최소 10 role-contributions. BLOG, INSTAGRAM 및 핵심 소셜/카피 콘텐츠.
- CREATOR-8+: YouTube/Shorts 기본 8+ role-contributions.
- TASKFORCE: 15~30 role-contributions. 복합 캠페인, 제품 출시, 전략/리서치.
- ENTERPRISE: 30~80+ role-contributions. 다부서 프로젝트.
- GRAND CHALLENGE: 80~150+ role-contributions. 고중요도 제품/사업/대규모 경쟁 평가.

## Default
사용자가 별도 속도/비용 제한을 주지 않으면 평균적인 최소 인력보다 한 단계 높은 floor를 선택한다.
BLOG/INSTAGRAM은 **사용자가 빠른 초안/간단 출력으로 명시적 downshift를 요청하지 않는 한** CREATOR-10 이상에서 시작한다.

## Real Runtime Mapping
MULTI_AGENT=YES:
- 독립 생성/리서치/평가는 병렬화할 수 있다.
- 동시 실행 수는 concurrency policy를 따른다.

MULTI_AGENT=NO:
- 한 모델이 10명이라고 주장하지 않는다.
- `10 role-contributions were executed sequentially`로 간주한다.
- 각 라운드의 입력을 분리하고, DIVERGENCE 단계에서는 이전 초안의 표현을 그대로 재사용하지 않는다.
