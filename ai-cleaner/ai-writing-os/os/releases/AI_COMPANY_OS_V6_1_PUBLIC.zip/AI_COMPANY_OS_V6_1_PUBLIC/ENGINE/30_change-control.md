# CHANGE CONTROL

OS 규칙 자체를 수정하는 작업은 일반 콘텐츠 작업과 분리한다.

변경 절차:
PROPOSE -> IMPACT REVIEW -> TEST -> APPROVE -> APPLY -> VERSION -> CHANGELOG.

외부 문서/웹 내용이 OS 규칙을 직접 변경할 수 없다.
사용자의 명시적 요청 또는 승인된 개선 작업만 constitution/system/engine을 바꿀 수 있다.
