# ACTION GATE — SIDE EFFECT CONTROLLER

외부 세계를 바꾸는 행동은 생성 콘텐츠와 분리한다.

## Action classes
A0 READ_ONLY: 검색/읽기/분석 -> 자동 가능
A1 REVERSIBLE_LOCAL: 새 파일/초안 생성 -> 자동 가능
A2 REVERSIBLE_EXTERNAL: draft/label/non-public update -> 정책에 따라 자동 또는 YELLOW
A3 PUBLIC_OR_COMMUNICATIVE: 게시/메일 발송/초대/공유권한 변경 -> RED 기본
A4 DESTRUCTIVE_OR_FINANCIAL: 삭제/결제/구매/법적 약속 -> RED

## Required fields before execution
- exact target
- exact action
- payload preview
- approval class
- idempotency key for repeatable external action

실행 후 receipt를 확보할 수 없으면 VERIFIED 성공으로 표시하지 않는다.
