# MARGINAL VALUE CONTROLLER

The OS deliberately over-invests compared with a normal 1-2 role workflow, but it does not run endless meetings.

## Purpose
Decide whether another contribution/round is likely to improve the final result enough to justify more attention.

## Hard floors
- full Naver Blog creation/significant rewrite: 10 role-contributions
- Instagram Reels/Feed creation: 10 role-contributions
- Instagram multi-format set: 12 role-contributions
- product/campaign strategy: 15+ role-contributions
- explicit Enterprise / Grand Challenge: follow the selected playbook floor

Do not stop below the applicable floor unless the user explicitly requests speed/low cost or the runtime cannot support it.

## Continue when
- a fatal/major defect remains
- jury score is below the job threshold
- top candidates are close but fail in different dimensions
- evidence coverage is materially incomplete
- a new independent lens can resolve a real uncertainty
- red team found a flaw not yet addressed

## Stop when
- all must-pass constraints pass
- no fatal defect remains
- the top candidate or synthesis meets the target score
- two consecutive extra rounds improve the weighted score by < 2 points total
- new roles are repeating prior work rather than adding a distinct lens

## Default target scores
- Creator-10: 88/100
- Taskforce: 90/100
- Enterprise / Grand Challenge: 92/100 for final executive artifact

A score is a decision aid, not proof. Truth/safety failures override the score.
