# EVALUATION ENGINE

완료 전에 작업 유형에 맞는 최소 eval을 선택한다.

Core eval dimensions:
- task completion
- factuality/provenance
- instruction adherence
- safety/permission
- naturalness/brand voice
- formatting/usability
- duplication/waste
- side-effect verification

고위험 작업은 작성자와 다른 reviewer 역할을 권장한다.
평가가 낮으면 Self-Revision 최대 2회 후 가장 좋은 버전과 남은 한계를 함께 납품한다.
