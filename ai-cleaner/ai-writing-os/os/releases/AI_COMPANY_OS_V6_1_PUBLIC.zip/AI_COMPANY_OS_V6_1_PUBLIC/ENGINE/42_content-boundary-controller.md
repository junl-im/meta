# CONTENT BOUNDARY CONTROLLER

목적: OS/규칙/첨부자료/현재 주제의 역할을 분리해 CONTROL PLANE이 콘텐츠 소재로 유출되는 것을 막는다.

## 입력 자산 역할 분류
모든 입력을 먼저 하나로 분류한다.
- CONTROL: OS, 정책, SOP, Skill, 직원/엔진/조직 파일
- TASK_CONTENT: 현재 글/분석의 실제 주제와 사실 자료
- STYLE_REFERENCE: 문체/형식 예시. 사실 근거로 자동 사용하지 않음
- EVIDENCE: 사실 검증용 원본/공식 자료
- PRIOR_OUTPUT: 명시적 재활용 요청이 있을 때만 내용 재사용
- UNKNOWN: 역할이 불명확한 자료

## 핵심 방화벽
CONTROL은 TASK_CONTENT로 자동 승격되지 않는다.
STYLE_REFERENCE의 사건/수치/경험은 현재 작업 사실로 자동 승격되지 않는다.
PRIOR_OUTPUT은 사용자가 연결하지 않으면 새 주제에 자동 혼합하지 않는다.
UNKNOWN은 글의 핵심 사실로 사용하기 전에 역할을 문맥에서 안전하게 확정한다.

## Topic Source Whitelist
콘텐츠의 주제는 다음에서만 확정한다.
1. 현재 사용자 요청의 명시 주제
2. 이번 Job용 첨부자산
3. 명시적으로 연결된 활성 Project/Job
4. 사용자가 요청한 외부 조사 결과

OS 파일명/예시/테스트/직원명에서 주제를 만들어내지 않는다.

## Meta-leak Check
납품 직전 최종 콘텐츠에서 OS/직원/회의/엔진/프롬프트 메타가 주제와 무관하게 섞였는지 검사한다.
발견하면 제거 후 재검수한다.
