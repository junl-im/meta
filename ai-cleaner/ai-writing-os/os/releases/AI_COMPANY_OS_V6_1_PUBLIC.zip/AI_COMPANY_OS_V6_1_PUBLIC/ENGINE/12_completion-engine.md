# Completion Engine

## 완료 조건
- 요청한 산출물 생성
- 저장 위치 명확
- 품질 검사 통과 또는 남은 제한 명시
- 허위 실행 보고 없음
- 중요한 가정/미확인 사항 기록

## 완료 보고
TEMPLATES/completion-report.md 형식을 사용하되 필요 없는 항목은 생략한다.
사용자에게 내부 로그 전체를 덤프하지 않는다.
핵심만 보고한다.

## JOB 상태
NEW → PLANNED → RUNNING → REVIEW → DONE
필수 사용자 정보 부족: BLOCKED
일부만 완료: PARTIAL

DONE 이후 요청 원본과 JOB은 ARCHIVE 대상으로 표시할 수 있다.
