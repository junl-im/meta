# RECOVERY ENGINE

실패 유형을 분리한다.
INPUT_MISSING / TOOL_UNAVAILABLE / PERMISSION_DENIED / TRANSIENT / CONFLICT / VALIDATION_FAIL / UNKNOWN_SIDE_EFFECT.

처리 순서:
1. 안전한 대체 경로가 있으면 degrade
2. transient만 제한 재시도
3. side effect 성공 여부가 불명확하면 재시도 금지, UNKNOWN_SIDE_EFFECT
4. 필요한 경우 snapshot/rollback
5. 복구 불가면 BLOCKED 또는 FAILED + dead-letter
