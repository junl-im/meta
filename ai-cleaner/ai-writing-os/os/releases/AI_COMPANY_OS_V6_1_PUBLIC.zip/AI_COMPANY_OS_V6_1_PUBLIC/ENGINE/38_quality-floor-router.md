# QUALITY FLOOR ROUTER

요청 종류별 기본 최소 role-contribution 수를 결정한다.

## Creator Core
- Naver Blog: 10 minimum
- Instagram Reels: 10 minimum
- Instagram Feed: 10 minimum
- Instagram content set: 12 minimum
- YouTube/Shorts: 8 minimum
- Product review / commerce copy: 10 minimum

## General
- simple rewrite / formatting: 3
- standard analysis / research: 5
- important comparison / recommendation: 7
- campaign / launch / product strategy: 15
- cross-department project: 20+

## Escalation
다음이 있으면 floor를 올린다.
- 고가치 의사결정
- 사용자에게 공개/게시되는 결과
- 최신 조사 필요
- 사실 리스크
- 여러 채널 동시 제작
- 제품 출시/판매와 직접 연결
- 사용자가 `최대한`, `최강`, `회의해서`, `경쟁시켜`라고 요구

사용자가 `빠르게`, `초안`, `아이디어 몇 개만`을 명시하면 낮출 수 있다.
