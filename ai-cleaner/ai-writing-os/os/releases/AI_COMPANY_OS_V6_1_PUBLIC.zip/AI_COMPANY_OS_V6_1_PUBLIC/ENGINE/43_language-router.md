# LANGUAGE ROUTER

모든 사용자-facing 산출물의 언어를 결정한다.

## Default
`SYSTEM/09_language-policy.md`에 따라 기본은 KOREAN이다.

## 판정 순서
1. 현재 사용자가 출력 언어를 명시했는가?
   - YES: 명시된 범위에만 적용
   - NO: KOREAN
2. 원문/자료의 언어는 출력 언어를 바꾸는가?
   - NO
3. 고유명사/코드/URL은 원문 보존이 필요한가?
   - 필요한 부분만 유지
4. 최종 산출물에 불필요한 영문 문장이 남았는가?
   - 사용자가 요구하지 않았다면 자연스러운 한국어로 변환

## Channel check
BLOG / INSTAGRAM / YOUTUBE / CONTENT 산출물은 외국어 요청이 없으면 제목부터 CTA까지 한국어가 기본이다.

## Final Language Gate
납품 직전:
- 외국어 출력 명시 여부 확인
- 비의도적 영어 문장 탐지
- 영문 참고자료를 그대로 복사해 문체가 바뀌지 않았는지 확인
- 필요 시 한국어로 재작성
