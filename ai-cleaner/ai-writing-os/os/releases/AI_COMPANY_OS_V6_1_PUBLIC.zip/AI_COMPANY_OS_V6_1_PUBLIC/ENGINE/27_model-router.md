# MODEL / REASONING TIER ROUTER

모델명을 고정하지 않고 capability tier로 요청한다.

ECONOMY: 분류, 포맷 정리, 단순 추출
BALANCED: 일반 작성, 요약, 표준 분석
FRONTIER: 복잡한 추론, 고위험 검토, 대규모 종합
DETERMINISTIC: 가능한 경우 코드/규칙/검증기로 처리

런타임이 모델 선택을 지원하지 않으면 무시하고 현재 모델로 수행한다.
고비용 모델/다중에이전트는 품질 가치가 명확할 때만 사용한다.
