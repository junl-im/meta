# ENGINE MAP

ENGINE은 "무엇을 쓸지"와 "어떻게 일할지"의 경계를 유지하면서 런타임 판단을 담당한다.

00. `00_engine-map.md` — engine map
01. `01_intent-detector.md` — intent detector
02. `02_context-detector.md` — context detector
03. `03_risk-detector.md` — risk detector
04. `04_research-detector.md` — research detector
05. `05_resource-detector.md` — resource detector
06. `06_workflow-builder.md` — workflow builder
07. `07_quality-gate.md` — quality gate
08. `08_memory-engine.md` — memory engine
09. `09_event-detector.md` — event detector
10. `10_conflict-resolver.md` — conflict resolver
11. `11_reuse-engine.md` — reuse engine
12. `12_completion-engine.md` — completion engine
13. `13_complexity-detector.md` — complexity detector
14. `14_workforce-allocator.md` — workforce allocator
15. `15_capability-router.md` — capability router
16. `16_state-manager.md` — state manager
17. `17_budget-controller.md` — budget controller
18. `18_project-controller.md` — project controller
19. `19_prompt-injection-firewall.md` — prompt injection firewall
20. `20_role-instantiator.md` — role instantiator
21. `21_skill-loader.md` — skill loader
22. `22_action-gate.md` — action gate
23. `23_evidence-controller.md` — evidence controller
24. `24_recovery-engine.md` — recovery engine
25. `25_concurrency-controller.md` — concurrency controller
26. `26_eval-engine.md` — eval engine
27. `27_model-router.md` — model router
28. `28_context-packager.md` — context packager
29. `29_idempotency-controller.md` — idempotency controller
30. `30_change-control.md` — change control
31. `31_data-classifier.md` — data classifier
32. `32_delivery-controller.md` — delivery controller
33. `33_deliberation-controller.md` — deliberation controller
34. `34_competition-engine.md` — competition engine
35. `35_red-team-engine.md` — red team engine
36. `36_jury-engine.md` — jury engine
37. `37_synthesis-engine.md` — synthesis engine
38. `38_quality-floor-router.md` — quality floor router
39. `39_marginal-value-controller.md` — marginal value controller
40. `40_diversity-controller.md` — diversity controller
41. `41_checkpoint-controller.md` — checkpoint controller
42. `42_content-boundary-controller.md` — OS/규칙(Control)과 실제 콘텐츠(Content)를 분리하고 메타 누출을 차단
43. `43_language-router.md` — 사용자-facing 출력 언어를 결정. 명시 지시 전까지 한국어 기본

## V6.1 mandatory preflight
모든 콘텐츠 생성 작업은 최소한 `01 intent -> 02 context -> 05 resource -> 42 content boundary -> 43 language -> workflow` 순서로 경계를 확정한 뒤 실행한다.
납품 직전 `42 + 43`을 다시 적용한다.
