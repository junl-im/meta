# WORKFORCE ALLOCATOR — QUALITY-BIASED

입력: Objective, Complexity, Quality Floor, Required Skills, Risk, Runtime capabilities, Budget.

1. ENGINE/38_quality-floor-router.md로 최소 role-contribution floor를 먼저 정한다.
2. ORGANIZATION/employee-registry에서 activation description/department/skills가 맞는 역할을 후보화한다.
3. BLOG/INSTAGRAM/YOUTUBE 등 deep SOP가 있으면 해당 channel playbook을 우선 연결한다.
4. Complexity 기준보다 Quality Floor가 높으면 Quality Floor를 따른다.
5. Role Instantiator가 Employee Card를 생성한다.
6. Skill Loader는 각 역할에 실제 필요한 Skill만 연결한다.
7. MULTI_AGENT가 있으면 독립안/독립평가를 병렬화하되 concurrency controller를 따른다.
8. MULTI_AGENT가 없으면 동일한 role-contribution 수를 순차 수행한다. 실제 10개 agent가 있었다고 허위 보고하지 않는다.
9. 생성 역할과 평가 역할을 분리한다.
10. same-fact duplicate research는 금지하되 동일 산출물에 대한 독립 creative candidates는 허용/권장한다.

## Default Staffing Bias
사용자가 속도/비용 최소화를 요구하지 않는 한 '최소 충분 인력'보다 한 단계 높은 팀을 선호한다.
- BLOG: CREATOR-10 minimum
- INSTAGRAM: CREATOR-10 minimum
- 제품/판매/캠페인: 15+; 중요한 전략이면 30+ 가능
- `최대한/최강/회의/경쟁` 요청: 적극적으로 상향

직원 수는 output 개수가 아니라 role-contribution 수다. 최종 산출물은 사용자가 요청한 개수만 납품한다.
