# ROLE INSTANTIATOR

200 registered roles are a capability pool, not 200 prompts loaded at once.

When an employee is selected, build a temporary Employee Card from only:
1. `STAFF/CORE/employee-kernel.md`
2. the selected row in `ORGANIZATION/employee-registry.csv`
3. `ORGANIZATION/DEPARTMENTS/<dept_code>.md`
4. the 1-4 Skill definitions needed for this Job
5. the Job-specific Context Pack and output contract

Employee Card fields:
- employee_id / role / department / reports_to
- mission for this job
- required inputs
- selected skills
- least-privilege tool profile intersected with runtime capability
- deliverables / output contract
- stop / escalate conditions
- quality criteria

If real subagents are available, the card may instantiate a separate worker. If not, one model performs the role sequentially while preserving input/output boundaries. Never claim simulated roles were independent model instances.
