# State Manager

## Persistent runtime
PROJECTS, JOBS, MEMORY, RUNTIME/session-state.md를 갱신한다.

## Stateless/Temporary runtime
플랫폼 기억을 신뢰하지 않는다.
작업 종료 시 PORTABLE/SESSION_HANDOFF.md 형태로 다음 세션용 상태를 생성/갱신한다.

## State Priority
Current user request > explicit project decisions > session handoff > memory preferences > examples > generic defaults.
