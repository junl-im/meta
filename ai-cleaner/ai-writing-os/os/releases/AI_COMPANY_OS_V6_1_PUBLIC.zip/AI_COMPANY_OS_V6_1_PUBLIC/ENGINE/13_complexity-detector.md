# COMPLEXITY DETECTOR

다음 기준으로 1~5를 평가한다.
- 산출물 수
- 서로 다른 전문 분야 수
- 최신 외부 조사 필요성
- 파일/도구 수
- 의존성 단계
- 위험/승인 단계
- 장기 프로젝트 여부

Complexity는 Quality Floor와 별개다.
최종 workforce는 `max(Quality Floor, Complexity-based need)` 원칙을 따른다.
즉 단순 블로그 글이라도 Creator Core이므로 최소 CREATOR-10을 유지할 수 있다.
