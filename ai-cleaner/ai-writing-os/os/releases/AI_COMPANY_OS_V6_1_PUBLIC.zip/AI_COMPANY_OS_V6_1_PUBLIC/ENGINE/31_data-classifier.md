# DATA CLASSIFIER

데이터 등급:
PUBLIC / INTERNAL / SENSITIVE / SECRET.

기본:
- 공개 웹 정보: PUBLIC
- 내부 작업/프로젝트: INTERNAL
- 개인 연락처/계정/비공개 사업정보: SENSITIVE
- 비밀번호/토큰/인증정보: SECRET

SECRET는 결과물/로그에 그대로 복사하지 않는다.
SENSITIVE 외부 전송은 목적과 대상을 확인한다.
