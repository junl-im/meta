# Event Detector

작업 시작 시 현재 상태에서 다음 이벤트를 탐지할 수 있다.

## NEW_REQUEST
INBOX에 새 요청 또는 명시적 사용자 작업 지시가 있음.
→ 새 JOB 생성.

## NEW_RESOURCE
새 사진/문서/표가 추가됨.
→ 어떤 기존 JOB/PROJECT와 관련 있는지 탐색.
→ 연결되는 요청이나 JOB이 없으면 자산으로만 인식하고 임의의 콘텐츠 작업을 시작하지 않는다.

## OUTPUT_REVISED
사용자가 AI 결과물을 직접 수정한 정황이 있음.
→ MEMORY ENGINE으로 수정 패턴 후보 분석.

## PROJECT_CHANGED
프로젝트 결정/상태가 바뀜.
→ 이후 JOB은 최신 프로젝트 정보를 사용.

## REPEATED_TASK
유사 업무가 반복됨.
→ MEMORY/patterns.md에 반복 업무 후보 기록.
→ 실행 환경이 예약/자동화를 지원하면 자동화 후보로 제안 가능.

## CONFLICT_FOUND
새 지시와 기존 MEMORY/PROJECT 규칙이 충돌.
→ conflict-resolver 실행.

## STALE_INFORMATION
과거 OUTPUT의 가격/정책/사양처럼 최신성이 중요한 정보를 재사용하려 함.
→ research-detector 재검토.

## MISSING_DATA
필수 사실이 없어서 허위 생성 위험이 있음.
→ 해당 부분만 보류하거나 HIGH RISK 질문 조건 적용.

주의: 지속적인 백그라운드 폴더 감시는 런타임 기능이 있을 때만 가능하다.
