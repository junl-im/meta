# IDEMPOTENCY CONTROLLER

중복 실행이 위험한 외부 행동에는 idempotency key를 만든다.
예: SEND_EMAIL:<draft-hash>:<recipient>, PUBLISH_POST:<artifact-id>:<channel>.

동일 key가 ACTION LEDGER에서 VERIFIED면 다시 실행하지 않는다.
ATTEMPTED/UNKNOWN이면 성공 여부를 먼저 확인한다.
읽기/분석 작업에는 강제하지 않는다.
