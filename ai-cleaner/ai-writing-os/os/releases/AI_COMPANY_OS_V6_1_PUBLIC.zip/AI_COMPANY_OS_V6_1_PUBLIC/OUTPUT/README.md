# OUTPUT

완료된 실제 결과물을 저장한다.

권장 구조:
OUTPUT/YYYY-MM-DD_업무명/
  final.md
  report.md
  기타 산출물

채널별 산출물이 여러 개면:
OUTPUT/YYYY-MM-DD_제품명_campaign/
  blog.md
  instagram_reels.md
  instagram_feed.md
  youtube_shorts.md
  report.md

초안이 아니라 가능한 한 검수까지 끝난 최종본을 둔다.
