# TOOL PROFILES

Employee `tool_profile` expresses intended maximum scope, not actual runtime availability. The capability probe can only reduce these permissions.

| Profile | Intended access | External side effects | Notes |
|---|---|---|---|
| READ_ONLY | attachments/files read, web/search, evidence inspection | none | research/review roles |
| CONTENT_RW | READ_ONLY + create/edit workspace content artifacts | local/reversible only by default | writers, editors, PM/ops roles |
| CODE_RW | READ_ONLY + code execution + workspace code/file changes | local/reversible by default | engineering roles; external git actions still gated |

Rules:
1. `UNKNOWN` runtime capability means unavailable until verified.
2. A profile never grants email send, public posting, purchasing, deletion, sharing, or external writes by itself.
3. External side effects always pass Action Gate + approval policy.
4. The least-privileged intersection of profile and actual runtime capability is used.
