# QUALITY THRESHOLDS

Default thresholds used by Jury / Marginal Value Controller.

| Mode | Target | Mandatory |
|---|---:|---|
| QUICK | 80 | truth/safety + requested artifact |
| STANDARD+ | 85 | truth/safety + instruction adherence |
| CREATOR-10 | 88 | channel checklist + truth + naturalness |
| TASKFORCE | 90 | evidence + cross-functional risks + usability |
| ENTERPRISE | 92 | phase acceptance criteria + auditability |
| GRAND CHALLENGE | 92 | same as Enterprise; additional rounds must add measurable value |

Fatal violations always fail regardless of numeric score.
