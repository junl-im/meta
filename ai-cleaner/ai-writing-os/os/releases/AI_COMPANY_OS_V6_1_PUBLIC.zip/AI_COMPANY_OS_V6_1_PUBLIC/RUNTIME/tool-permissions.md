# RUNTIME TOOL PERMISSIONS

이 파일은 정적 권한 선언이 아니라 런타임별 확인 결과를 기록하는 곳이다.

기본값은 DENY/UNKNOWN.
실제 발견된 기능만 AVAILABLE로 바꾼다.

| Capability | Availability | Allowed scope | Side effect | Approval |
|---|---|---|---|---|
| FILE_READ | UNKNOWN | current attachments/workspace | no | GREEN |
| FILE_WRITE | UNKNOWN | workspace/output | local | GREEN/YELLOW |
| WEB_RESEARCH | UNKNOWN | public web | no | GREEN |
| CODE_EXEC | UNKNOWN | sandbox/workspace | possible | YELLOW |
| EMAIL_SEND | UNKNOWN | explicit account | yes | RED |
| CALENDAR_WRITE | UNKNOWN | explicit account | yes | RED |
| DRIVE_WRITE | UNKNOWN | explicit account | yes | YELLOW/RED |
| GIT_PUSH | UNKNOWN | explicit repo | yes | RED unless pre-authorized |
| PUBLIC_POST | UNKNOWN | explicit channel | yes | RED |
