#!/usr/bin/env python3
from pathlib import Path
import csv, json, re, sys, collections
ROOT=Path(__file__).resolve().parents[2]
errors=[]; warnings=[]

def err(x): errors.append(x)
def warn(x): warnings.append(x)

required=[
'OS_IDENTITY.json','00_OPEN_FIRST.md','01_OWNER_PROFILE.md','02_DEFAULTS_AND_BOUNDARIES.md','03_TASK_ROUTER.md','04_BLOG_CORE.md','05_INSTAGRAM_CORE.md','06_PRODUCT_ENTERPRISE_CORE.md','07_STATE_AND_UPDATE.md','QUICK_COMMANDS.md','BOOT.md','START_HERE.md','VERSION.md','MANIFEST.md','PORTABLE/PORTABLE_CORE.md',
'ORGANIZATION/employee-registry.csv','ORGANIZATION/department-registry.md','ORGANIZATION/org-chart.md',
'RUNTIME/tool-profiles.md','RUNTIME/00_capability-probe.md','RUNTIME/reality-ladder.md',
'SKILLS/skill-registry.csv','ENGINE/20_role-instantiator.md','ENGINE/22_action-gate.md',
'ENGINE/28_context-packager.md','ENGINE/33_deliberation-controller.md','ENGINE/38_quality-floor-router.md',
'ENGINE/39_marginal-value-controller.md','ENGINE/40_diversity-controller.md','ENGINE/41_checkpoint-controller.md',
'ENGINE/42_content-boundary-controller.md','ENGINE/43_language-router.md',
'SYSTEM/08_content-boundary.md','SYSTEM/09_language-policy.md',
'DELIBERATION/blog-10-playbook.md','DELIBERATION/instagram-10-playbook.md','DELIBERATION/product-120-playbook.md',
'EMPLOYEES/BLOG/sop.md','EMPLOYEES/BLOG/checklist.md','EMPLOYEES/INSTAGRAM/sop.md',
'GOVERNANCE/reasoning-privacy.md','RECOVERY/recovery-policy.md','AUDIT/event-log.md',
'TOOLS/tool-registry.md','CONNECTORS/connector-registry.md',
'SCHEMAS/context-pack.schema.json','SCHEMAS/input-asset.schema.json',
'RUNTIME/scripts/test_content_contract.py','RUNTIME/scripts/test_v6_1_second_pass.py','TESTS/V6_1_SECOND_PASS_REGRESSION.md','TESTS/V5_5_BOUNDARY_LANGUAGE_TESTS.md','TESTS/CROSS_MODEL_ACCEPTANCE.md'
]
for r in required:
    if not (ROOT/r).exists(): err(f'MISSING required file: {r}')

# Employees
emp_path=ROOT/'ORGANIZATION/employee-registry.csv'
employees=[]
if emp_path.exists():
    with emp_path.open(encoding='utf-8-sig',newline='') as f: employees=list(csv.DictReader(f))
    ids=[r.get('employee_id','') for r in employees]
    if len(ids)!=len(set(ids)): err('DUPLICATE employee_id')
    if len(ids)<200: err(f'employee registry below 200: {len(ids)}')
    emp_ids=set(ids)
    # reports_to integrity
    for r in employees:
        rt=(r.get('reports_to') or '').strip()
        if r['employee_id']=='EXE-001':
            if rt!='HUMAN_OWNER': err('EXE-001 must report to HUMAN_OWNER')
        elif not rt or rt not in emp_ids:
            err(f"INVALID reports_to: {r['employee_id']} -> {rt}")
        if rt==r['employee_id']: err(f"SELF report: {r['employee_id']}")

# Skills
skill_path=ROOT/'SKILLS/skill-registry.csv'
skill_rows=[]
if skill_path.exists():
    with skill_path.open(encoding='utf-8-sig',newline='') as f: skill_rows=list(csv.DictReader(f))
    sids=[r.get('skill_id','') for r in skill_rows]
    if len(sids)!=len(set(sids)): err('DUPLICATE skill_id')
    skill_ids=set(sids)
    for sid in sids:
        if not (ROOT/'SKILLS/library'/sid/'SKILL.md').exists(): err(f'MISSING skill file: {sid}')
    if len(sids)<90: err(f'skill registry unexpectedly small: {len(sids)}')
    for r in employees:
        for sid in [x.strip() for x in re.split(r'[;,|]',r.get('default_skills','')) if x.strip()]:
            if sid not in skill_ids: err(f"UNRESOLVED employee skill: {r['employee_id']} -> {sid}")

# Departments
codes=sorted(set(r['dept_code'] for r in employees))
for code in codes:
    if not (ROOT/'ORGANIZATION/DEPARTMENTS'/f'{code}.md').exists(): err(f'MISSING department handbook: {code}')

# Tool profiles
profile_text=(ROOT/'RUNTIME/tool-profiles.md').read_text(encoding='utf-8') if (ROOT/'RUNTIME/tool-profiles.md').exists() else ''
for prof in sorted(set(r.get('tool_profile','') for r in employees)):
    if prof and prof not in profile_text: err(f'UNDEFINED tool_profile: {prof}')

# Engine numbering unique
nums=collections.defaultdict(list)
for p in (ROOT/'ENGINE').glob('*.md'):
    m=re.match(r'(\d+)_',p.name)
    if m: nums[m.group(1)].append(p.name)
for n,names in nums.items():
    if len(names)>1: err(f'DUPLICATE engine prefix {n}: {names}')
for i in range(0,44):
    if f'{i:02d}' not in nums: warn(f'engine prefix gap: {i:02d}')

# JSON schemas parse and meta-validate when jsonschema is available
for p in (ROOT/'SCHEMAS').glob('*.json'):
    try:
        obj=json.loads(p.read_text(encoding='utf-8'))
        try:
            import jsonschema
            jsonschema.Draft202012Validator.check_schema(obj)
        except ImportError:
            pass
        except Exception as e:
            err(f'INVALID JSON schema {p.name}: {e}')
    except Exception as e:
        err(f'INVALID JSON {p.name}: {e}')

# Critical cross-file contracts
checks={
'BOOT.md':['V6.1','00_OPEN_FIRST.md','product-120-playbook.md','42_content-boundary-controller.md','43_language-router.md'],
'00_OPEN_FIRST.md':['OS는 글 소재가 아니다','한국어','Creator-10','Fast Path'],
'02_DEFAULTS_AND_BOUNDARIES.md':['OUTPUT_LANGUAGE: ko','OS_ROLE: CONTROL_ONLY','새 주제 오염 방지'],
'03_TASK_ROUTER.md':['애매한 `글 써줘`','일반 한국어 글','최종 납품 전 공통 Gate'],
'PORTABLE/PORTABLE_CORE.md':['V6.1','100-140','내돈내산','CONTROL PLANE','Korean-first'],
'EMPLOYEES/BLOG/sop.md':['4~6','내돈내산','허위','자연스러움'],
'EMPLOYEES/INSTAGRAM/reels.md':['한 줄','타임코드'],
'SYSTEM/08_content-boundary.md':['CONTROL PLANE','CONTENT PLANE','이걸 기준으로','소재가 아니다'],
'SYSTEM/09_language-policy.md':['한국어','영문','외국어 자료','명시'],
'ENGINE/42_content-boundary-controller.md':['CONTROL','TASK_CONTENT','Topic Source Whitelist'],
'ENGINE/43_language-router.md':['KOREAN','외국어 출력','Final Language Gate'],
'DELIBERATION/blog-10-playbook.md':['10 Roles','SENIOR SYNTHESIS EDITOR'],
'DELIBERATION/instagram-10-playbook.md':['10 Roles','SENIOR SOCIAL SYNTHESIS EDITOR'],
}
for rel,needles in checks.items():
    p=ROOT/rel
    if p.exists():
        txt=p.read_text(encoding='utf-8')
        for needle in needles:
            if needle not in txt: err(f'CONTRACT drift: {rel} missing {needle!r}')

# Critical path references in markdown
roots=[p.name for p in ROOT.iterdir() if p.is_dir()]
roots_re='(?:'+'|'.join(re.escape(x) for x in sorted(roots,key=len,reverse=True))+')'
path_re=re.compile(r'(?<![\w.-])('+roots_re+r'/[A-Za-z0-9_./가-힣+()<>-]+\.(?:md|json|csv|txt|py))')
for p in ROOT.rglob('*.md'):
    txt=p.read_text(encoding='utf-8')
    for m in path_re.finditer(txt):
        ref=m.group(1).rstrip('.,;)')
        if '<' in ref or '>' in ref or '*' in ref: continue
        if not (ROOT/ref).exists(): err(f'BROKEN path ref: {p.relative_to(ROOT)} -> {ref}')

# Active V6 entrypoints must identify the current release. Historical/deep V5.5 files may remain as inherited contracts.
for rel in ['00_OPEN_FIRST.md','BOOT.md','START_HERE.md','PORTABLE/PORTABLE_CORE.md','VERSION.md']:
    p=ROOT/rel
    if p.exists() and 'V6.1' not in p.read_text(encoding='utf-8'):
        warn(f'CURRENT version label missing in active entrypoint: {rel}')

# V6.1 second-pass contracts
for rel,toks in {
    '05_INSTAGRAM_CORE.md':['3종 세트','후기형 정보 콘텐츠'],
    'ENGINE/33_deliberation-controller.md':['CREATOR-8+','빠른 초안/간단 출력'],
    'PORTABLE/TEMP_CHAT_INSTRUCTIONS.md':['V6.1','00_OPEN_FIRST.md'],
    'DELIBERATION/product-120-playbook.md':['Ordinary `대기업 모드`','100명 이상'],
}.items():
    p=ROOT/rel
    if not p.exists(): err(f'MISSING {rel}')
    else:
        txt=p.read_text(encoding='utf-8')
        for t in toks:
            if t not in txt: err(f'V6.1 contract drift: {rel} missing {t!r}')

# Historical execution docs must not remain in root.
for old in ['AUDIT_V5_5.md','RELEASE_NOTES_V5_3.md','RELEASE_NOTES_V5_5.md','CHANGELOG_V5_1_TO_V5_2.md','PRODUCTION_AUDIT.md','REALITY_AUDIT.md']:
    if (ROOT/old).exists(): err(f'HISTORICAL control doc left at root: {old}')

print('AI COMPANY OS V6.1 ZIP-ONLY VALIDATION')
print('root:',ROOT)
print('employees:',len(employees),'skills:',len(skill_rows),'departments:',len(codes),'engines:',len(nums),'schemas:',len(list((ROOT/'SCHEMAS').glob('*.json'))))
if warnings:
    print('WARNINGS:',len(warnings))
    for w in warnings: print('-',w)
if errors:
    print('FAIL:',len(errors))
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS')
