#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import sys, re, secrets
ROOT=Path(__file__).resolve().parents[2]
objective=' '.join(sys.argv[1:]).strip() or 'UNSPECIFIED OBJECTIVE'
now=datetime.now(timezone.utc)
ts=now.strftime('%Y%m%dT%H%M%S')+f'{now.microsecond//1000:03d}Z'
slug=re.sub(r'[^A-Za-z0-9가-힣]+','-',objective)[:40].strip('-') or 'job'
job_id=f'JOB-{ts}-{secrets.token_hex(2).upper()}'
p=ROOT/'JOBS'/f'{job_id}_{slug}.md'
p.write_text(f'''# JOB CARD\n\nJob ID: {job_id}\nStatus: NEW\nPriority: P2\nCreated: {now.isoformat()}\nObjective: {objective}\nRisk: UNASSESSED\nQuality Floor: UNASSESSED\nOwner: UNASSIGNED\n\n## Acceptance Criteria\n\n## Constraints\n\n## Inputs / Dynamic Fields\n\n## Facts / Evidence\n\n## Dependencies\n\n## Workforce / Deliberation\n\n## Outputs\n\n## QA / Jury\n\n## Audit / Receipts\n\n## Checkpoint / Next Actions\n''',encoding='utf-8')
print(p)
