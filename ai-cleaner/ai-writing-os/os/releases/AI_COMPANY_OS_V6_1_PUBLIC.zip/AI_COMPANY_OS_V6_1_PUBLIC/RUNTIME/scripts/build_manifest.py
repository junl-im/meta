#!/usr/bin/env python3
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[2]
file_count=sum(1 for p in ROOT.rglob('*') if p.is_file())
dir_count=sum(1 for p in ROOT.rglob('*') if p.is_dir())
with (ROOT/'ORGANIZATION/employee-registry.csv').open(encoding='utf-8-sig') as f: employees=list(csv.DictReader(f))
with (ROOT/'SKILLS/skill-registry.csv').open(encoding='utf-8-sig') as f: skills=list(csv.DictReader(f))
engine_count=sum(1 for p in (ROOT/'ENGINE').glob('*.md'))
dep_count=sum(1 for p in (ROOT/'ORGANIZATION/DEPARTMENTS').glob('*.md'))
schema_count=sum(1 for p in (ROOT/'SCHEMAS').glob('*.json'))
text=f'''# MANIFEST — AI COMPANY OS V6.0 ZIP-ONLY

Generated from the current package structure.

## Integrity summary
- registered employees: {len(employees)}
- registered skills: {len(skills)}
- department handbooks: {dep_count}
- engine modules: {engine_count}
- schemas: {schema_count}
- total files: {file_count}
- total directories: {dir_count}

## Tier 0 — ZIP-only Fast Path
- `00_OPEN_FIRST.md` — first entrypoint and master contract
- `01_OWNER_PROFILE.md` — condensed owner preferences
- `02_DEFAULTS_AND_BOUNDARIES.md` — Korean/control/content defaults
- `03_TASK_ROUTER.md` — natural-language task routing
- `04_BLOG_CORE.md` — Naver Blog Creator-10 core
- `05_INSTAGRAM_CORE.md` — Instagram Creator-10 core
- `06_PRODUCT_ENTERPRISE_CORE.md` — product / enterprise staged review
- `07_STATE_AND_UPDATE.md` — honest persistence/update rules
- `QUICK_COMMANDS.md` — human quick commands
- `BOOT.md` — full runtime boot
- `PORTABLE/PORTABLE_CORE.md` — single-file fallback

## Tier 1 — Deep governance
- `SYSTEM/`, `GOVERNANCE/`, `RUNTIME/`, `REALITY_PRINCIPLES.md`

## Tier 2 — Company / execution
- `EXECUTIVE/`, `ORGANIZATION/`, `ENGINE/`, `STAFF/CORE/`, `SKILLS/`

## Tier 3 — Deep creator contracts
- `EMPLOYEES/BLOG/`, `EMPLOYEES/INSTAGRAM/`
- `DELIBERATION/blog-10-playbook.md`
- `DELIBERATION/instagram-10-playbook.md`
- `DELIBERATION/product-120-playbook.md`

## Tier 4 — State / operations
- `PROJECTS/`, `PROJECTS_ACTIVE/`, `JOBS/`, `QUEUE/`, `MEMORY/`, `KNOWLEDGE/`, `LEDGERS/`, `AUDIT/`, `OUTPUT/`

## Tier 5 — Reliability
- `EVALS/`, `TESTS/`, `RECOVERY/`, `OBSERVABILITY/`, `SCHEMAS/`
- `RUNTIME/scripts/validate_os.py`
- `RUNTIME/scripts/test_content_contract.py`
- `RUNTIME/scripts/test_v6_zip_only.py`

## Mandatory load policy
Start at `00_OPEN_FIRST.md`. Use the root Fast Path for ordinary work and read the Deep Library only when needed. The OS ZIP is CONTROL, not article subject matter, unless the user explicitly makes the OS the topic. Default user-facing language is Korean unless another output language is explicitly requested.
'''
(ROOT/'MANIFEST.md').write_text(text,encoding='utf-8')
print(ROOT/'MANIFEST.md')
