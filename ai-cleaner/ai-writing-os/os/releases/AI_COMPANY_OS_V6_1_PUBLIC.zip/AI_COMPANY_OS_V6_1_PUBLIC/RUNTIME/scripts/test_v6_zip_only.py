#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
errors=[]

def need(rel,*tokens):
    p=ROOT/rel
    if not p.exists():
        errors.append(f'MISSING {rel}'); return
    s=p.read_text(encoding='utf-8')
    for t in tokens:
        if t not in s: errors.append(f'{rel} missing {t!r}')

for rel in ['OS_IDENTITY.json','00_OPEN_FIRST.md','01_OWNER_PROFILE.md','02_DEFAULTS_AND_BOUNDARIES.md','03_TASK_ROUTER.md','04_BLOG_CORE.md','05_INSTAGRAM_CORE.md','06_PRODUCT_ENTERPRISE_CORE.md','07_STATE_AND_UPDATE.md','QUICK_COMMANDS.md']:
    if not (ROOT/rel).exists(): errors.append(f'MISSING {rel}')
need('00_OPEN_FIRST.md','OS는 글 소재가 아니다','한국어','Fast Path','Creator-10')
need('02_DEFAULTS_AND_BOUNDARIES.md','OUTPUT_LANGUAGE: ko','OS_ROLE: CONTROL_ONLY','새 주제 오염 방지')
need('03_TASK_ROUTER.md','애매한 `글 써줘`','일반 한국어 글','최종 납품 전 공통 Gate')
need('04_BLOG_CORE.md','4~6','내돈내산','Creator-10','허위')
need('05_INSTAGRAM_CORE.md','릴스 자막만','한 줄','Creator-10','3종 세트','후기형 정보 콘텐츠')
need('06_PRODUCT_ENTERPRISE_CORE.md','30~80+','100~140+','Red Team','Jury')
need('07_STATE_AND_UPDATE.md','ZIP 자체가 실제로 갱신','수정했다고 거짓말하지')
need('START_HERE.md','별도 설치 없이','00_OPEN_FIRST.md')
need('PORTABLE/TEMP_CHAT_INSTRUCTIONS.md','V6.1','00_OPEN_FIRST.md')
need('ENGINE/33_deliberation-controller.md','CREATOR-8+','빠른 초안/간단 출력')
need('DELIBERATION/product-120-playbook.md','Ordinary `대기업 모드`','100명 이상')
print('AI COMPANY OS V6.1 ZIP-ONLY CONTRACT TEST')
if errors:
    print('FAIL',len(errors))
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS')
