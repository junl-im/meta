#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[2]
out=ROOT/'PORTABLE'/'SESSION_EXPORT.md'
state=(ROOT/'RUNTIME'/'session-state.md').read_text(encoding='utf-8') if (ROOT/'RUNTIME'/'session-state.md').exists() else ''
parts=['# SESSION EXPORT','',f'Generated: {datetime.now(timezone.utc).isoformat()}','', '## Runtime State','',state]
for title,rel in [('Decisions','MEMORY/decisions.md'),('Preferences','MEMORY/preferences.md'),('Memory Candidates','MEMORY/candidates.md'),('Action Receipts','AUDIT/action-receipts.md')]:
    p=ROOT/rel
    parts += ['',f'## {title}','',p.read_text(encoding='utf-8') if p.exists() else 'None']
out.write_text('\n'.join(parts),encoding='utf-8')
print(out)
