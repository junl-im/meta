#!/usr/bin/env python3
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[2]
errors=[]

def text(rel):
    p=ROOT/rel
    if not p.exists():
        errors.append(f'MISSING {rel}')
        return ''
    return p.read_text(encoding='utf-8')

def need(rel,*tokens):
    s=text(rel)
    for t in tokens:
        if t not in s: errors.append(f'{rel} missing {t!r}')

def forbid(rel,*tokens):
    s=text(rel)
    for t in tokens:
        if t in s: errors.append(f'{rel} contains forbidden stale token {t!r}')

# Identity / canonical authority
try:
    ident=json.loads((ROOT/'OS_IDENTITY.json').read_text(encoding='utf-8'))
    if ident.get('version')!='6.1': errors.append('OS_IDENTITY version is not 6.1')
    if ident.get('role')!='CONTROL_PLANE': errors.append('OS_IDENTITY role is not CONTROL_PLANE')
except Exception as e:
    errors.append(f'OS_IDENTITY invalid: {e}')
need('00_OPEN_FIRST.md','CANONICAL AUTHORITY','가장 높은 version','OS 식별')

# Instagram broad request must be 3-set without fabricated experience
need('05_INSTAGRAM_CORE.md','3종','Reels','Feed')
for rel in ['EMPLOYEES/INSTAGRAM/sop.md','DELIBERATION/instagram-10-playbook.md']:
    need(rel,'3종','REELS','FEED')
need('05_INSTAGRAM_CORE.md','Shopping/Review Style','후기형 정보 콘텐츠')
need('EMPLOYEES/INSTAGRAM/review.md','체험자인 척하지 않는다','장점','아쉬운 점')

# Explicit QUICK is the only creator downshift path
need('ENGINE/33_deliberation-controller.md','빠른 초안/간단 출력','CREATOR-8+')
need('CEO.md','명시적으로 downshift','Truth/Format Gate')
for rel in ['ENGINE/33_deliberation-controller.md','CEO.md','BOOT.md']:
    forbid(rel,'무조건 CREATOR-10')

# Product workforce tiers
need('06_PRODUCT_ENTERPRISE_CORE.md','30~80+','100~140+','기획·생산','출시·판매')
need('DELIBERATION/product-120-playbook.md','Ordinary `대기업 모드`','100명 이상')
forbid('DELIBERATION/product-120-playbook.md','`100명 이상`, `대기업 모드`, `Grand Challenge`')

# Temp chat starts from fast path
need('PORTABLE/TEMP_CHAT_INSTRUCTIONS.md','V6.1','00_OPEN_FIRST.md')

# Historical execution docs are isolated
for old in ['AUDIT_V5_5.md','RELEASE_NOTES_V5_3.md','RELEASE_NOTES_V5_5.md','CHANGELOG_V5_1_TO_V5_2.md','PRODUCTION_AUDIT.md','REALITY_AUDIT.md']:
    if (ROOT/old).exists(): errors.append(f'historical doc still in root: {old}')
    if not (ROOT/'ARCHIVE/RELEASE_HISTORY'/old).exists(): errors.append(f'historical doc not archived: {old}')

print('AI COMPANY OS V6.1 SECOND-PASS REGRESSION')
if errors:
    print('FAIL',len(errors))
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS')
