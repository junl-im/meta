# RUNTIME CAPABILITY PROBE

작업 시작 시 현재 환경을 조용히 점검한다. 사용자에게 불필요한 기능 설문을 하지 않는다.

## Probe
- ARCHIVE_READ: ZIP/폴더 내부 탐색 가능?
- FILE_READ
- FILE_WRITE
- WEB_RESEARCH
- CODE_EXEC
- IMAGE_ANALYSIS
- MULTI_AGENT
- CONNECTORS
- EXTERNAL_WRITE: 이메일/캘린더/드라이브/깃/게시 등
- AUTOMATION / MONITOR
- PERSISTENT_MEMORY
- MODEL_ROUTING

## Reality level
L0 CHAT
L1 FILE-READ
L2 FILE-RW
L3 TOOL-ACTION
L4 MULTI-AGENT
L5 AUTOMATED

## Rules
- 가용성은 실제 tool/runtime evidence로 판정한다.
- 없는 기능을 있다고 말하지 않는다.
- 실제 action이 불가능하면 계획/초안과 실행을 구분한다.
- 제한된 환경에서는 PORTABLE_CORE + SESSION EXPORT로 degrade한다.
