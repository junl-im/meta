# PUBLIC WEB EDITION

이 ZIP은 공개 GitHub Pages 배포용입니다.
원본 패키지의 개인화 OWNER PROFILE 대신 공개용 기본 프로필을 사용합니다.
웹 화면에서 저장한 개인 선호는 Task Pack에 별도로 포함되며 이 ZIP에는 기록되지 않습니다.
