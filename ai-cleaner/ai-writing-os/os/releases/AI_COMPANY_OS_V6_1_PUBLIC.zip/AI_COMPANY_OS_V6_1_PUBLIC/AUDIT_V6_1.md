# AI COMPANY OS V6.1 — SECOND-PASS AUDIT

## 발견 및 수정
1. Instagram 포괄 요청이 2종(Reels+Feed)으로 후퇴한 회귀 → 원래 사용자 규칙대로 3종 세트 복원.
2. QUICK/downshift 허용 규칙과 `무조건 Creator-10` 문구 충돌 → 명시적 QUICK만 예외로 전역 통일.
3. YouTube 8+와 Creator-10 표기가 충돌 → BLOG/Instagram 10+, YouTube/Shorts 8+로 분리.
4. `대기업 모드`와 명시적 100+가 섞여 과잉 Product-120을 유발 → ENTERPRISE 30~80+와 PRODUCT-120 100~140+ 트리거 분리.
5. TEMP_CHAT가 구버전 V5.5/BOOT-first로 남음 → V6.1/00_OPEN_FIRST-first로 수정.
6. 과거 감사/릴리스 문서가 루트에 있어 모델이 구버전 규칙을 참고할 위험 → ARCHIVE/RELEASE_HISTORY로 격리.
7. 여러 ZIP/여러 OS 버전 동시 첨부 시 어떤 것을 CONTROL로 삼을지 불명확 → OS_IDENTITY.json + highest-version resolver 추가.

## 유지된 핵심 계약
- OS는 콘텐츠 소재가 아니라 CONTROL PLANE.
- 외국어 출력 명시 전 사용자-facing 출력은 한국어.
- 새 명시 주제는 이전 소재를 기본 리셋.
- 허위 구매/사용/가족반응/효과 금지.
- BLOG Creator-10 기본.
- Instagram Creator-10 기본 및 포괄 요청 3종 세트.
- 실제 multi-agent가 없으면 독립 에이전트를 실행했다고 주장하지 않음.
