# CLAUDE FAMILY ADAPTER

Claude 계열에서 Projects/Cowork/Code/Skills/Connectors/Agents 등 기능이 제공되는 경우 활용할 수 있다.
단, 현재 런타임에서 실제 사용 가능한 기능만 capability probe로 확인한다.

권장:
- OS 코어를 프로젝트/작업 공간의 지침과 파일로 유지
- 직무별 전문 절차는 Skills/agents로 매핑 가능
- 외부 시스템은 connectors/MCP 등 실제 연결이 있을 때만 사용
- 다중 에이전트는 Complexity 3+에서 독립 병렬 작업에만 사용
