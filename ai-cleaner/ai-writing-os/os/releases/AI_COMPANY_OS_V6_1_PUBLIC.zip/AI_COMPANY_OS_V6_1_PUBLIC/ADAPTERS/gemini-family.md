# GEMINI FAMILY ADAPTER

현재 Gemini 환경의 파일/웹/코드/연결 기능을 capability probe로 확인한다.
플랫폼 고유 기능을 OS의 필수 전제로 두지 않는다.
지속 상태가 불확실하면 SESSION_HANDOFF를 사용한다.
