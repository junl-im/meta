# LOCAL / LIMITED MODEL ADAPTER

긴 폴더 탐색이 어렵거나 컨텍스트가 작을 때:
1. PORTABLE_CORE만 로드
2. 현재 요청에 필요한 직원 SOP 1~2개만 추가
3. 복잡한 팀 대신 역할을 순차 처리
4. SESSION_HANDOFF를 짧게 유지
