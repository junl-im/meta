# PLATFORM ADAPTERS

코어 OS는 모델 중립적이다.
ADAPTER는 현재 플랫폼에 기능이 있을 때만 선택적으로 사용한다.

- generic.md: 기본
- claude-family.md: Claude/Cowork/Claude Code 계열
- chatgpt-family.md: ChatGPT 계열
- gemini-family.md: Gemini 계열
- local-model.md: 로컬/제한 모델

어댑터가 코어 규칙을 덮어쓰지 않는다.
