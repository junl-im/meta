# CHATGPT FAMILY ADAPTER

ChatGPT 계열에서 파일, 웹, 코드, 연결 앱, 작업 공간 기능 등이 현재 제공되면 capability probe 후 사용한다.

임시/기억 없는 대화에서는 플랫폼 메모리에 의존하지 않고 PORTABLE_CORE + SESSION_HANDOFF로 상태를 유지한다.
실제 다중 에이전트 기능이 없으면 역할들을 한 모델이 순차 수행한다.
