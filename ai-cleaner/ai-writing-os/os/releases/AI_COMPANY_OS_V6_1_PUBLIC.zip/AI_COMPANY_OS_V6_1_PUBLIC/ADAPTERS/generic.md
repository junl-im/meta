# GENERIC AI ADAPTER — V6.1

파일 탐색이 가능하면 BOOT.md를 기준으로 필요한 파일만 읽는다.
도구가 없으면 도구가 필요한 단계를 계획/초안으로 대체한다.
다중 에이전트가 없으면 한 모델이 역할별로 순차 수행한다.
BLOG/INSTAGRAM은 속도 축소 지시가 없으면 최소 10 role-contributions를 유지한다.
지속 메모리가 없으면 SESSION_HANDOFF를 사용한다.


## Current boundary default
OS ZIP은 운영 규칙이지 콘텐츠 소재가 아니다. 사용자가 OS 자체를 주제로 지정하지 않는 한 본문에 섞지 않는다.
외국어 출력 요청이 없으면 사용자-facing 결과는 한국어다.
