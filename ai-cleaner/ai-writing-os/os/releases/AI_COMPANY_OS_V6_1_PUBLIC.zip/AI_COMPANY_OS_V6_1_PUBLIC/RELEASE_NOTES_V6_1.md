# RELEASE NOTES — V6.1 ZIP ONLY

V6.0 second-pass production audit 결과를 반영한 안정화 릴리스.

- Instagram broad request 3-set 복원
- Quick mode / Creator-10 충돌 제거
- YouTube 8+ floor 분리
- ENTERPRISE vs PRODUCT-120 트리거 명확화
- temporary-chat boot order 최신화
- historical control docs archive 격리
- OS_IDENTITY.json 추가 및 다중 OS 버전 선택 규칙 추가
- 회귀 테스트 강화
