# PRODUCT-120 — ENTERPRISE PRODUCT LIFECYCLE PLAYBOOK

Use when the Human Owner explicitly requests 100+ contributions / Grand Challenge, or asks for a product to be developed and reviewed across the full lifecycle from opportunity/problem and production/feasibility through launch/sales. Ordinary `대기업 모드` or company-wide review may stay at ENTERPRISE 30-80+ unless scope justifies PRODUCT-120.

This playbook targets **100-140 meaningful role-contributions across phases**, not 100 people talking in one room. Distinct registered employees should be used where the runtime supports true multi-agent execution; otherwise execute bounded role-contributions by phase and label them accurately.

## Phase 0 — Executive Charter (5)
CEO / Chief of Staff / Strategy / Finance / Risk define objective, success metrics, non-negotiables, budget/time assumptions.
Output: Project Brief + acceptance criteria.

## Phase 1 — Customer & Problem Discovery (15)
Customer/VOC, UX research, complaint patterns, jobs-to-be-done, purchase barriers, unmet needs.
Run independent discovery pods before synthesis.
Output: evidence-backed problem map.

## Phase 2 — Market / Competitor / Evidence (15)
Market framing, competitors, substitutes, trend, policy/spec constraints, source verification.
Output: Evidence Pack + opportunity map.

## Phase 3 — Concept Tournament (20)
4-6 proposal teams generate deliberately different product concepts/positioning/offer models.
Blind divergence -> Red Team -> Jury -> top 2-3 advance.
Output: ranked concepts and rejection reasons.

## Phase 4 — Product / UX / Technical Feasibility (15)
Requirements, UX flows, technical feasibility, production/automation considerations, failure modes.
Output: prototype/spec recommendation + feasibility risks.

## Phase 5 — Unit Economics / Pricing / Commerce (10)
Cost ranges, pricing options, margin logic, offer architecture, purchase journey, procurement assumptions.
Output: commercial model with assumptions.

## Phase 6 — Brand / Creative / Content / GTM Competition (20)
Brand angle, naming/message territories, Naver Blog, Instagram, YouTube/short-form, creative briefs, growth campaign options.
Creator work uses its channel-specific deep SOP and Creator-10 where applicable; shared evidence is reused.
Output: launch content system + campaign candidates.

## Phase 7 — Risk / Compliance / Failure Red Team (10)
Claims, privacy, policy, operational, reputation, support, technical and launch failure scenarios.
Output: mitigations + launch blockers.

## Phase 8 — Independent Jury & Executive Synthesis (8)
Cross-functional judges score evidence, customer fit, feasibility, economics, differentiation, execution risk, and launch readiness.
Output: executive recommendation / go-no-go / required revisions.

## Phase 9 — Launch Readiness & Feedback Loop (10)
Operations, analytics, support, QA, rollback/recovery, KPI instrumentation, post-launch learning plan.
Output: launch checklist + dashboard plan + iteration cadence.

## Contribution target
Base total: 128 contributions. Adjust within 100-140 using the Marginal Value Controller.
Do not reduce below 100 when the Human Owner explicitly requests `100명 이상`, `Grand Challenge`, or a full product lifecycle from planning/production through launch/sales, unless runtime limits make that impossible; if limited, state the actual contribution count and degraded mode.

## Meeting types
No all-hands freeform debate. Use: Brief Council / independent pods / proposal tournament / Red Team / Jury / Executive Board / checkpoint review.
