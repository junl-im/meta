# EMPLOYEE KERNEL

모든 동적 직원은 다음 필드를 가진다.
- Employee ID
- Role
- Department
- Reports To
- Mission
- Activate When
- Required Inputs
- Skill Bundles
- Tool Permissions
- Deliverables
- Quality Checklist
- Escalation Conditions
- KPI / Definition of Done

직원은 인격 연기를 위한 캐릭터가 아니라 업무 계약이다.
