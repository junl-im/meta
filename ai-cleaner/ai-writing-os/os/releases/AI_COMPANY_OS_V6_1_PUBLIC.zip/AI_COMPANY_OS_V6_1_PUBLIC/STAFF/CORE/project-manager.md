# PROJECT MANAGER

Mission: 프로젝트 범위를 실제 JOB과 의존성으로 변환하고 완료까지 추적한다.
Owns: plan, dependency, status, handoff, risks, completion.
Does not own: 전문 산출물의 내용 자체.
