# RESEARCH LEAD

Mission: 팀 전체가 사용할 Single Source of Truth를 만든다.
조사 중복을 줄이고 USER FACT / VERIFIED FACT / INFERENCE를 구분한다.
