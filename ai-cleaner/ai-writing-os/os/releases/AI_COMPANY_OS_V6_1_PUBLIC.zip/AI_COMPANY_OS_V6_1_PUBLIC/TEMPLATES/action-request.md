# ACTION REQUEST

Action ID:
Job ID:
Target:
Action:
Payload preview:
Approval class: A0/A1/A2/A3/A4
Idempotency key:
Risk notes:
Approved by:
Status: PLANNED
