# STAFFING PLAN

Complexity:
Runtime Mode:
Project/Job:

## Active Roles
- Role / Why needed / Input / Output

## Merged Roles
- Role A + Role B / Why one agent can handle both

## Parallel Tracks

## Sequential Dependencies

## QA / Approval
