# EXECUTIVE BRIEF

## Objective
## What Changed
## Key Decisions
## Result
## Risks / Caveats
## Human Approval Needed
## Next Best Action
