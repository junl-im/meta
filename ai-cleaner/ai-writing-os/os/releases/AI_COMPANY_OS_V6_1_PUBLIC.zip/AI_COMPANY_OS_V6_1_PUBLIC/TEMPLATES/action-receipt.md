# ACTION RECEIPT

Action ID:
Idempotency key:
Attempted at:
Tool/connector:
Status: VERIFIED / FAILED / UNKNOWN
External receipt/id:
Verification evidence:
Notes:
