# 완료 보고

상태: DONE / PARTIAL / BLOCKED

## 완료한 작업

## 생성 결과
- 파일/산출물:

## 사용한 주요 자료

## 검수
- Global Quality: PASS / FAIL
- Employee Quality: PASS / FAIL
- 자동 수정 횟수:

## 적용한 가정
없으면 생략.

## 확인하지 못한 항목 / 제한
없으면 "없음".

## MEMORY 후보
없으면 생략.
