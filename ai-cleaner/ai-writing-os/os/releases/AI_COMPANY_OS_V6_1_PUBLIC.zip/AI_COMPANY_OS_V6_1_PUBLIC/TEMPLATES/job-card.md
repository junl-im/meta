# JOB CARD

## 기본
JOB ID:
상태: NEW / PLANNED / RUNNING / REVIEW / DONE / PARTIAL / BLOCKED
생성일:

## 사용자 요청

## 최종 산출물

## 작업 유형

## 담당 직원 / 팀

## 연결 프로젝트

## 입력 자료

## CONTENT SCOPE
CONTROL_ASSETS:
TASK_CONTENT:
STYLE_REFERENCES:
PRIOR_OUTPUT_REUSE: YES / NO
CONTENT_SCOPE_RESET: YES / NO

## OUTPUT LANGUAGE
기본: ko
사용자 명시 override:

## USER FACT

## OBSERVED FACT

## VERIFIED FACT

## INFERENCE / 가정

## 금지 / 주의

## RESEARCH
YES / NO
필요한 항목:

## RISK
LOW / MEDIUM / HIGH
이유:

## WORKFLOW

## OUTPUT 경로

## QUALITY RESULT

## MEMORY 후보
