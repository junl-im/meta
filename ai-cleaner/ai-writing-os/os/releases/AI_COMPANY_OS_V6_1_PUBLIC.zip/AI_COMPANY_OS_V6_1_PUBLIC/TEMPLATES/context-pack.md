# CONTEXT PACK

## Objective
## Constraints

## Content Boundary
CONTROL_ASSETS: OS/정책/SOP/직원/엔진 등. 작업 방법에만 사용, 콘텐츠 소재 금지.
TASK_CONTENT: 이번 작업의 실제 주제/키워드/사진/문서/사실.
STYLE_REFERENCES: 문체/형식만 참고. 예시 속 경험/사실 도용 금지.
PRIOR_OUTPUT_REUSE: YES / NO
CONTENT_SCOPE_RESET: YES / NO

## Output Language
OUTPUT_LANGUAGE: ko (default)
LANGUAGE_OVERRIDE_SOURCE: 사용자 명시 지시가 있을 때만 기록

## Relevant User Facts
## Project Decisions
## Employee Card
## Skills Loaded
## Evidence Pack
## Examples Loaded
## Output Contract
## Approval / Risk Constraints
