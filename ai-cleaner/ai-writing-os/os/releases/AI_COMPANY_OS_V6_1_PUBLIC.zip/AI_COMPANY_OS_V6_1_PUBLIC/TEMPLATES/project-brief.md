# PROJECT BRIEF

Project ID:
Objective:
Success Criteria:
Audience/User:
Known Facts:
Constraints:
Non-goals:
Deliverables:
Required Departments:
Risks:
Approval Gates:
