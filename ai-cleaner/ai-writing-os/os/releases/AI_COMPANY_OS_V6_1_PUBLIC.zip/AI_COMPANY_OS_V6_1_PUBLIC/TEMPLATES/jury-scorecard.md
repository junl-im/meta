# JURY SCORECARD

Candidate:
Reviewer role:

- User Fit /25:
- Naturalness /20:
- Truth & Evidence /20:
- Usefulness /15:
- Channel Fit /10:
- SEO/Engagement /10:

Fatal violations:
Strengths:
Weaknesses:
Recommendation: ADVANCE / REVISE / REJECT
