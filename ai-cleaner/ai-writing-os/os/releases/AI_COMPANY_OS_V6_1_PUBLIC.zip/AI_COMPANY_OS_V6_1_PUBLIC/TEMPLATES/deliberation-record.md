# DELIBERATION RECORD

Job ID:
Quality Floor:
Runtime: MULTI_AGENT / SEQUENTIAL_ROLES
Contributions Planned:
Contributions Completed:

## Brief
- Objective:
- Audience:
- User facts:
- Constraints:
- Non-negotiables:

## Candidates
- Candidate A:
- Candidate B:
- Other:

## Red Team Findings
- Critical:
- Major:
- Minor:

## Jury
- User Fit:
- Naturalness:
- Truth/Evidence:
- Usefulness:
- Channel Fit:
- SEO/Engagement:

## Synthesis Decision
Selected strengths:
Rejected elements:
Final revision notes:
