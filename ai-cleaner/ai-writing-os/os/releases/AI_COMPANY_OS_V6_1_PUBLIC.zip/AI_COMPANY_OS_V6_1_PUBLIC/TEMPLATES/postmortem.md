# POSTMORTEM

Incident/Job ID:
Impact:
What failed:
Root cause:
What was already changed externally:
Recovery performed:
Preventive rule/change:
Regression test added:
