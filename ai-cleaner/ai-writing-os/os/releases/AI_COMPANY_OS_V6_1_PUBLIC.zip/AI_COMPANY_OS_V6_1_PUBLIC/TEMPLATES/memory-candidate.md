# MEMORY CANDIDATE

날짜:
범위: GLOBAL / BLOG / INSTAGRAM / YOUTUBE / DESIGN / DEV / PROJECT
신뢰도: LOW / MEDIUM / HIGH

## 관찰

## 반복 가능 규칙 후보

## 근거

## 승격 조건
예: 같은 수정이 한 번 더 반복되면 preferences.md로 이동.
