# EMPLOYEE CARD

Employee ID:
Role:
Department:
Reports to:
Mission for this Job:
Inputs:
Skills loaded:
Allowed tools:
Forbidden actions:
Escalate when:
Output contract:
Quality criteria:
