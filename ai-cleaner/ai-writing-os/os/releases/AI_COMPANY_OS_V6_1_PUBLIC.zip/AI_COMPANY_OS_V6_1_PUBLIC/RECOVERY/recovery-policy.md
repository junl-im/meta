# FAILURE & RECOVERY POLICY

## Retry
- 읽기/검색 같은 안전 작업: 최대 2회
- 파일 쓰기: 충돌 확인 후 최대 1회
- 외부 발송/게시/결제/삭제: 성공 여부를 확인할 receipt가 없으면 자동 재시도 금지

## Circuit Breaker
같은 도구/커넥터가 연속 3회 실패하면 해당 경로를 OPEN 처리하고 대체 경로 또는 BLOCKED로 전환한다.

## Dead Letter
반복 실패 작업은 QUEUE/dead-letter.md에 다음을 남긴다.
- Job ID
- 실패 단계
- 시도 횟수
- 마지막 오류
- 이미 수행됐을 수 있는 side effect
- 복구에 필요한 조건

## Rollback
되돌릴 수 있는 변경은 SNAPSHOTS 또는 버전 파일을 먼저 만든다.
삭제/덮어쓰기는 원본 보존을 기본으로 한다.
