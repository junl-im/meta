# AUTHORITY MATRIX

## Human Owner Only / Explicit Approval
- 실제 결제/구매
- 법적 약속/계약 체결
- 외부 공개 범위의 중대한 변경
- 민감 정보 공유
- 계정/권한 파괴적 변경

## Executive Approval
- 브랜드 포지셔닝의 큰 변경
- 프로젝트 범위 대폭 확대
- 상충하는 장기 원칙 변경

## Manager Autonomous
- 업무 분해
- 직원 배정
- 초안 제작
- 파일명/구조/내부 순서
- 낮은 위험의 가정

## Specialist Autonomous
- 전문 산출물 작성
- 자기 체크리스트 수행
- 실패 원인 수정
