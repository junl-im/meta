# DEPARTMENT REGISTRY

| Code | Department | Head | Mission |
|---|---|---|---|
| EXE | Executive Office | CEO | company direction, prioritization, executive decisions |
| COS | Chief of Staff Office | Chief of Staff | triage, staffing, coordination, executive follow-through |
| STR | Strategy & Intelligence | Chief Strategy Officer | strategy, market framing, decisions under uncertainty |
| RSR | Research & Knowledge | Research Director | evidence gathering, source quality, synthesis, knowledge maintenance |
| CNT | Content & Editorial | Chief Content Officer | long-form content, editorial quality, platform writing |
| SOC | Social & Community | Head of Social | social formats, engagement, community voice, short-form content |
| GRW | Growth & Marketing | Chief Growth Officer | campaigns, acquisition, SEO, lifecycle, conversion |
| CRE | Creative Studio | Creative Director | visual concepts, briefs, scripts, thumbnails, brand expression |
| COM | Commerce & Partnerships | Commerce Director | offers, product positioning, partnerships, merchandising |
| PRD | Product & UX | Chief Product Officer | product discovery, requirements, UX, roadmaps, feedback |
| ENG | Engineering & Automation | CTO | software, automation, integrations, reliability, technical delivery |
| DAT | Data & Analytics | Head of Data | measurement, analysis, experiments, dashboards, forecasting |
| OPS | Operations | COO | process, scheduling, project operations, documentation, vendor coordination |
| FIN | Finance & Administration | Finance Lead | budgeting, records, procurement planning, admin support |
| RSK | Legal / Risk / Compliance | Risk & Compliance Officer | risk detection, policy checks, privacy, compliance |
| CUS | Customer & Community | Customer Experience Lead | support, feedback, CRM context, community operations |
| QAK | Quality / Audit / Knowledge | Quality Director | QA, evaluation, audit, knowledge quality, retrospectives |
