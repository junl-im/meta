# EMPLOYEE REGISTRY — 200 ROLE POOL

This is the canonical human-readable view of `employee-registry.csv`. `reports_to` uses Employee IDs (or `HUMAN_OWNER`).

| ID | Dept | Role | Level | Reports To | Skills | Tool | Risk |
|---|---|---|---|---|---|---|---|
| EXE-001 | EXE | AI CEO | EXEC | HUMAN_OWNER | executive-briefing;decision-analysis;prioritization | CONTENT_RW | LOW |
| EXE-002 | EXE | Executive Decision Analyst | SPECIALIST | EXE-001 | executive-briefing;decision-analysis;prioritization | CONTENT_RW | LOW |
| EXE-003 | EXE | Portfolio Prioritization Advisor | SPECIALIST | EXE-001 | executive-briefing;decision-analysis;prioritization | CONTENT_RW | LOW |
| EXE-004 | EXE | Executive Briefing Officer | SPECIALIST | EXE-001 | executive-briefing;decision-analysis;prioritization | CONTENT_RW | LOW |
| EXE-005 | EXE | Business Model Advisor | SPECIALIST | EXE-001 | executive-briefing;decision-analysis;prioritization | CONTENT_RW | LOW |
| EXE-006 | EXE | Strategic Tradeoff Reviewer | SPECIALIST | EXE-001 | executive-briefing;decision-analysis;prioritization | CONTENT_RW | LOW |
| COS-001 | COS | Chief of Staff | EXEC | EXE-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-002 | COS | Intake Triage Manager | MANAGER | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-003 | COS | Workforce Planner | SPECIALIST | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-004 | COS | Cross-Department Coordinator | SPECIALIST | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-005 | COS | Executive Follow-up Manager | MANAGER | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-006 | COS | Decision Log Steward | SPECIALIST | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-007 | COS | Meeting Synthesizer | SPECIALIST | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| COS-008 | COS | Escalation Coordinator | SPECIALIST | COS-001 | triage;workforce-planning;handoff;state-management | CONTENT_RW | LOW |
| STR-001 | STR | Chief Strategy Officer | EXEC | EXE-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-002 | STR | Market Strategy Lead | MANAGER | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-003 | STR | Competitive Strategy Analyst | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-004 | STR | Scenario Planner | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-005 | STR | Opportunity Analyst | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-006 | STR | Positioning Strategist | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-007 | STR | Business Research Strategist | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-008 | STR | Decision Analyst | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| STR-009 | STR | Risk-Reward Analyst | SPECIALIST | STR-001 | strategy;scenario-planning;competitive-analysis;decision-analysis | READ_ONLY | LOW |
| RSR-001 | RSR | Research Director | EXEC | EXE-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-002 | RSR | Web Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-003 | RSR | Primary Source Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-004 | RSR | Fact Checker | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-005 | RSR | Citation Specialist | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-006 | RSR | Product Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-007 | RSR | Policy Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-008 | RSR | Scientific Evidence Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-009 | RSR | Trend Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-010 | RSR | Competitor Researcher | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-011 | RSR | Source Quality Reviewer | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| RSR-012 | RSR | Knowledge Curator | SPECIALIST | RSR-001 | web-research;fact-check;source-quality;evidence-ledger | READ_ONLY | LOW |
| CNT-001 | CNT | Chief Content Officer | EXEC | EXE-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-002 | CNT | Editorial Director | MANAGER | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-003 | CNT | Naver Blog Lead | MANAGER | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-004 | CNT | Naver Blog Writer | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-005 | CNT | Naver SEO Specialist | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-006 | CNT | Review Content Writer | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-007 | CNT | Information Article Writer | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-008 | CNT | Long-form Writer | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-009 | CNT | Copy Editor | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-010 | CNT | Korean Naturalness Editor | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-011 | CNT | Headline Specialist | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-012 | CNT | CTA Copywriter | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-013 | CNT | Content Repurposing Editor | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| CNT-014 | CNT | Blog QA Editor | SPECIALIST | CNT-001 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| SOC-001 | SOC | Head of Social | EXEC | EXE-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-002 | SOC | Instagram Lead | MANAGER | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-003 | SOC | Reels Script Writer | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-004 | SOC | Instagram Feed Writer | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-005 | SOC | Social Review Writer | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-006 | SOC | Social SEO Specialist | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-007 | SOC | Hook Specialist | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-008 | SOC | Engagement Copywriter | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-009 | SOC | Community Caption Writer | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-010 | SOC | Short-form Editor | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-011 | SOC | Social Trend Analyst | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| SOC-012 | SOC | Platform QA Reviewer | SPECIALIST | SOC-001 | shortform-writing;instagram;hook-writing;social-qa | CONTENT_RW | LOW |
| GRW-001 | GRW | Chief Growth Officer | EXEC | EXE-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-002 | GRW | Campaign Strategist | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-003 | GRW | SEO Strategist | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-004 | GRW | Keyword Researcher | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-005 | GRW | Conversion Copywriter | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-006 | GRW | Funnel Analyst | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-007 | GRW | Lifecycle Marketer | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-008 | GRW | Audience Segmentation Analyst | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-009 | GRW | Growth Experiment Designer | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-010 | GRW | Landing Page Strategist | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-011 | GRW | Retention Strategist | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| GRW-012 | GRW | Channel Mix Planner | SPECIALIST | GRW-001 | seo;keyword-research;campaign-planning;conversion-copy | CONTENT_RW | MEDIUM |
| CRE-001 | CRE | Creative Director | EXEC | EXE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-002 | CRE | Visual Concept Strategist | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-003 | CRE | Design Brief Writer | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-004 | CRE | Thumbnail Strategist | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-005 | CRE | Storyboard Artist | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-006 | CRE | Image Selection Editor | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-007 | CRE | Brand Voice Designer | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-008 | CRE | Creative QA Reviewer | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-009 | CRE | Presentation Visual Planner | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| CRE-010 | CRE | Photo Content Analyst | SPECIALIST | CRE-001 | creative-brief;storyboard;image-analysis;brand-expression | CONTENT_RW | LOW |
| COM-001 | COM | Commerce Director | EXEC | EXE-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-002 | COM | Product Positioning Specialist | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-003 | COM | Offer Strategist | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-004 | COM | Product Comparison Analyst | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-005 | COM | Merchandising Planner | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-006 | COM | Partnership Researcher | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-007 | COM | Affiliate Content Planner | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-008 | COM | Purchase Journey Analyst | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-009 | COM | Pricing Context Analyst | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| COM-010 | COM | Commerce QA Reviewer | SPECIALIST | COM-001 | product-positioning;comparison;offer-design;commerce-copy | CONTENT_RW | MEDIUM |
| PRD-001 | PRD | Chief Product Officer | EXEC | EXE-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-002 | PRD | Product Manager | MANAGER | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-003 | PRD | Product Discovery Researcher | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-004 | PRD | Requirements Analyst | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-005 | PRD | UX Researcher | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-006 | PRD | UX Writer | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-007 | PRD | Feature Prioritization Analyst | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-008 | PRD | Roadmap Planner | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-009 | PRD | Feedback Synthesizer | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| PRD-010 | PRD | Acceptance Criteria Reviewer | SPECIALIST | PRD-001 | requirements;ux-research;prioritization;acceptance-criteria | CONTENT_RW | LOW |
| ENG-001 | ENG | CTO | EXEC | EXE-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-002 | ENG | Software Architect | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-003 | ENG | Backend Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-004 | ENG | Frontend Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-005 | ENG | Automation Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-006 | ENG | Integration Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-007 | ENG | API Specialist | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-008 | ENG | Debugging Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-009 | ENG | Test Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-010 | ENG | Security Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-011 | ENG | DevOps Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-012 | ENG | Git Workflow Specialist | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-013 | ENG | Code Reviewer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-014 | ENG | Technical Writer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| ENG-015 | ENG | Reliability Engineer | SPECIALIST | ENG-001 | software-engineering;debugging;testing;automation | CODE_RW | MEDIUM |
| DAT-001 | DAT | Head of Data | EXEC | EXE-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-002 | DAT | Data Analyst | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-003 | DAT | Spreadsheet Analyst | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-004 | DAT | Analytics Engineer | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-005 | DAT | Experiment Analyst | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-006 | DAT | KPI Designer | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-007 | DAT | Dashboard Analyst | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-008 | DAT | Forecasting Analyst | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-009 | DAT | Data Quality Reviewer | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| DAT-010 | DAT | Attribution Analyst | SPECIALIST | DAT-001 | data-analysis;spreadsheet-analysis;kpi-design;data-quality | CONTENT_RW | LOW |
| OPS-001 | OPS | COO | EXEC | EXE-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-002 | OPS | Operations Manager | MANAGER | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-003 | OPS | Project Manager | MANAGER | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-004 | OPS | Task Coordinator | SPECIALIST | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-005 | OPS | Process Designer | SPECIALIST | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-006 | OPS | SOP Writer | SPECIALIST | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-007 | OPS | Scheduler | SPECIALIST | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-008 | OPS | Vendor Research Coordinator | SPECIALIST | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-009 | OPS | Document Controller | SPECIALIST | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-010 | OPS | Asset Manager | MANAGER | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-011 | OPS | Inbox Manager | MANAGER | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-012 | OPS | Archive Manager | MANAGER | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| OPS-013 | OPS | Automation Operations Manager | MANAGER | OPS-001 | project-management;sop-writing;scheduling;operations-control | CONTENT_RW | MEDIUM |
| FIN-001 | FIN | Finance Lead | EXEC | EXE-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| FIN-002 | FIN | Budget Analyst | SPECIALIST | FIN-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| FIN-003 | FIN | Cost Controller | SPECIALIST | FIN-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| FIN-004 | FIN | Procurement Planner | SPECIALIST | FIN-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| FIN-005 | FIN | Invoice Data Reviewer | SPECIALIST | FIN-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| FIN-006 | FIN | Administrative Coordinator | SPECIALIST | FIN-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| FIN-007 | FIN | Resource Planning Analyst | SPECIALIST | FIN-001 | budgeting;cost-analysis;procurement-planning | CONTENT_RW | HIGH |
| RSK-001 | RSK | Risk & Compliance Officer | EXEC | EXE-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-002 | RSK | Privacy Reviewer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-003 | RSK | Prompt Injection Reviewer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-004 | RSK | Health Claims Safety Reviewer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-005 | RSK | Advertising Disclosure Reviewer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-006 | RSK | Legal Issue Spotter | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-007 | RSK | Permission Reviewer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-008 | RSK | Data Classification Officer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-009 | RSK | External Action Approver | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| RSK-010 | RSK | Security Policy Reviewer | SPECIALIST | RSK-001 | risk-review;privacy;permission-check;prompt-injection-defense | CONTENT_RW | HIGH |
| CUS-001 | CUS | Customer Experience Lead | EXEC | EXE-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-002 | CUS | Support Triage Specialist | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-003 | CUS | Customer Reply Writer | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-004 | CUS | Feedback Analyst | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-005 | CUS | Community Manager | MANAGER | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-006 | CUS | FAQ Curator | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-007 | CUS | Complaint Pattern Analyst | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-008 | CUS | CRM Context Reviewer | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-009 | CUS | Voice-of-Customer Analyst | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| CUS-010 | CUS | Customer Journey Reviewer | SPECIALIST | CUS-001 | support;feedback-analysis;community-management;customer-voice | CONTENT_RW | LOW |
| QAK-001 | QAK | Quality Director | EXEC | EXE-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-002 | QAK | General QA Reviewer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-003 | QAK | Factuality Reviewer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-004 | QAK | Instruction Compliance Reviewer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-005 | QAK | Brand Voice Reviewer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-006 | QAK | Artifact Validator | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-007 | QAK | Audit Reviewer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-008 | QAK | Memory Curator | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-009 | QAK | Knowledge Base Maintainer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-010 | QAK | Regression Test Designer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-011 | QAK | Postmortem Analyst | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| QAK-012 | QAK | Delivery Reviewer | SPECIALIST | QAK-001 | quality-gate;evals;audit;memory-curation | READ_ONLY | LOW |
| CNT-015 | CNT | Blog Intake & Fact Auditor | SPECIALIST | CNT-003 | naver-blog;fact-check;evidence-ledger;natural-korean | READ_ONLY | LOW |
| CNT-016 | CNT | Blog Search Intent & Keyword Planner | SPECIALIST | CNT-003 | naver-seo;keyword-research;naver-blog;seo | READ_ONLY | LOW |
| CNT-017 | CNT | Blog Reader & Voice Advocate | SPECIALIST | CNT-003 | brand-voice;natural-korean;storytelling;naver-blog | CONTENT_RW | LOW |
| CNT-018 | CNT | Blog Structure Architect | SPECIALIST | CNT-003 | longform-writing;naver-blog;storytelling;image-selection | CONTENT_RW | LOW |
| CNT-019 | CNT | Blog Naturalness Writer A | SPECIALIST | CNT-003 | natural-korean;longform-writing;storytelling;naver-blog | CONTENT_RW | LOW |
| CNT-020 | CNT | Blog Utility Writer B | SPECIALIST | CNT-003 | natural-korean;longform-writing;naver-blog;seo | CONTENT_RW | LOW |
| CNT-021 | CNT | Blog SEO & Mobile Reviewer | SPECIALIST | CNT-003 | naver-seo;seo;editorial-qa;natural-korean | READ_ONLY | LOW |
| CNT-022 | CNT | Blog AI-Tone & Brand Editor | SPECIALIST | CNT-002 | brand-voice;natural-korean;editorial-qa;longform-writing | CONTENT_RW | LOW |
| CNT-023 | CNT | Blog Fact Safety & Media Reviewer | SPECIALIST | CNT-002 | fact-check;health-claims-safety;editorial-qa;image-analysis | READ_ONLY | MEDIUM |
| CNT-024 | CNT | Senior Blog Synthesis Editor | MANAGER | CNT-002 | natural-korean;longform-writing;naver-blog;editorial-qa | CONTENT_RW | LOW |
| SOC-013 | SOC | Social Intake & Truth Auditor | SPECIALIST | SOC-002 | instagram;fact-check;evidence-ledger;social-qa | READ_ONLY | LOW |
| SOC-014 | SOC | Instagram Audience Psychology Analyst | SPECIALIST | SOC-002 | audience-segmentation;instagram;purchase-journey;social-qa | READ_ONLY | LOW |
| SOC-015 | SOC | Hook Challenger A | SPECIALIST | SOC-002 | hook-writing;instagram-reels;natural-korean;cta-writing | CONTENT_RW | LOW |
| SOC-016 | SOC | Hook Challenger B | SPECIALIST | SOC-002 | hook-writing;instagram-reels;natural-korean;cta-writing | CONTENT_RW | LOW |
| SOC-017 | SOC | Instagram Format Writer | SPECIALIST | SOC-002 | instagram;instagram-reels;instagram-feed;natural-korean | CONTENT_RW | LOW |
| SOC-018 | SOC | Instagram Detail & Value Writer | SPECIALIST | SOC-002 | instagram-feed;storytelling;natural-korean;seo | CONTENT_RW | LOW |
| SOC-019 | SOC | Instagram Engagement & CTA Strategist | SPECIALIST | SOC-002 | cta-writing;conversion-copy;instagram;audience-segmentation | CONTENT_RW | LOW |
| SOC-020 | SOC | Instagram Mobile Naturalness Editor | SPECIALIST | SOC-002 | natural-korean;instagram-reels;social-qa;brand-voice | CONTENT_RW | LOW |
| SOC-021 | SOC | Instagram Fact Review Ethics QA | SPECIALIST | SOC-002 | fact-check;social-qa;health-claims-safety;ad-disclosure-check | READ_ONLY | MEDIUM |
| SOC-022 | SOC | Senior Social Synthesis Editor | MANAGER | SOC-001 | instagram;natural-korean;social-qa;brand-voice | CONTENT_RW | LOW |
