# Data & Analytics — Department Handbook

Code: DAT
Head: `DAT-001` Head of Data

## Mission
Measure performance, analyze data, design experiments, and forecast.

## Registered roles
- `DAT-001` Head of Data (EXEC) -> EXE-001
- `DAT-002` Data Analyst (SPECIALIST) -> DAT-001
- `DAT-003` Spreadsheet Analyst (SPECIALIST) -> DAT-001
- `DAT-004` Analytics Engineer (SPECIALIST) -> DAT-001
- `DAT-005` Experiment Analyst (SPECIALIST) -> DAT-001
- `DAT-006` KPI Designer (SPECIALIST) -> DAT-001
- `DAT-007` Dashboard Analyst (SPECIALIST) -> DAT-001
- `DAT-008` Forecasting Analyst (SPECIALIST) -> DAT-001
- `DAT-009` Data Quality Reviewer (SPECIALIST) -> DAT-001
- `DAT-010` Attribution Analyst (SPECIALIST) -> DAT-001

## Default skill pool
data-analysis, spreadsheet-analysis, kpi-design, data-quality

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
