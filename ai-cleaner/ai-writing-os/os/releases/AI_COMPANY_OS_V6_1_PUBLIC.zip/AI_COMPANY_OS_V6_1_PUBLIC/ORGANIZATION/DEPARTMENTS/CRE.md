# Creative Studio — Department Handbook

Code: CRE
Head: `CRE-001` Creative Director

## Mission
Develop visual concepts, scripts, design briefs, thumbnails, and brand expression.

## Registered roles
- `CRE-001` Creative Director (EXEC) -> EXE-001
- `CRE-002` Visual Concept Strategist (SPECIALIST) -> CRE-001
- `CRE-003` Design Brief Writer (SPECIALIST) -> CRE-001
- `CRE-004` Thumbnail Strategist (SPECIALIST) -> CRE-001
- `CRE-005` Storyboard Artist (SPECIALIST) -> CRE-001
- `CRE-006` Image Selection Editor (SPECIALIST) -> CRE-001
- `CRE-007` Brand Voice Designer (SPECIALIST) -> CRE-001
- `CRE-008` Creative QA Reviewer (SPECIALIST) -> CRE-001
- `CRE-009` Presentation Visual Planner (SPECIALIST) -> CRE-001
- `CRE-010` Photo Content Analyst (SPECIALIST) -> CRE-001

## Default skill pool
creative-brief, storyboard, image-analysis, brand-expression

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
