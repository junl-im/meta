# Content & Editorial — Department Handbook

Code: CNT
Head: `CNT-001` Chief Content Officer

## Mission
Produce and edit long-form content with channel-specific quality.

## Registered roles
- `CNT-001` Chief Content Officer (EXEC) -> EXE-001
- `CNT-002` Editorial Director (MANAGER) -> CNT-001
- `CNT-003` Naver Blog Lead (MANAGER) -> CNT-001
- `CNT-004` Naver Blog Writer (SPECIALIST) -> CNT-001
- `CNT-005` Naver SEO Specialist (SPECIALIST) -> CNT-001
- `CNT-006` Review Content Writer (SPECIALIST) -> CNT-001
- `CNT-007` Information Article Writer (SPECIALIST) -> CNT-001
- `CNT-008` Long-form Writer (SPECIALIST) -> CNT-001
- `CNT-009` Copy Editor (SPECIALIST) -> CNT-001
- `CNT-010` Korean Naturalness Editor (SPECIALIST) -> CNT-001
- `CNT-011` Headline Specialist (SPECIALIST) -> CNT-001
- `CNT-012` CTA Copywriter (SPECIALIST) -> CNT-001
- `CNT-013` Content Repurposing Editor (SPECIALIST) -> CNT-001
- `CNT-014` Blog QA Editor (SPECIALIST) -> CNT-001
- `CNT-015` Blog Intake & Fact Auditor (SPECIALIST) -> CNT-003
- `CNT-016` Blog Search Intent & Keyword Planner (SPECIALIST) -> CNT-003
- `CNT-017` Blog Reader & Voice Advocate (SPECIALIST) -> CNT-003
- `CNT-018` Blog Structure Architect (SPECIALIST) -> CNT-003
- `CNT-019` Blog Naturalness Writer A (SPECIALIST) -> CNT-003
- `CNT-020` Blog Utility Writer B (SPECIALIST) -> CNT-003
- `CNT-021` Blog SEO & Mobile Reviewer (SPECIALIST) -> CNT-003
- `CNT-022` Blog AI-Tone & Brand Editor (SPECIALIST) -> CNT-002
- `CNT-023` Blog Fact Safety & Media Reviewer (SPECIALIST) -> CNT-002
- `CNT-024` Senior Blog Synthesis Editor (MANAGER) -> CNT-002

## Default skill pool
natural-korean, longform-writing, naver-blog, editorial-qa, fact-check, evidence-ledger, naver-seo, keyword-research, seo, brand-voice, storytelling, image-selection, health-claims-safety, image-analysis

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
