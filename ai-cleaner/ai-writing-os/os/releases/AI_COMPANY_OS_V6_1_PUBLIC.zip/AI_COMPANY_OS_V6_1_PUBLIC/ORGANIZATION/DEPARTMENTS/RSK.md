# Legal / Risk / Compliance — Department Handbook

Code: RSK
Head: `RSK-001` Risk & Compliance Officer

## Mission
Review risk, privacy, claims, permissions, and compliance boundaries.

## Registered roles
- `RSK-001` Risk & Compliance Officer (EXEC) -> EXE-001
- `RSK-002` Privacy Reviewer (SPECIALIST) -> RSK-001
- `RSK-003` Prompt Injection Reviewer (SPECIALIST) -> RSK-001
- `RSK-004` Health Claims Safety Reviewer (SPECIALIST) -> RSK-001
- `RSK-005` Advertising Disclosure Reviewer (SPECIALIST) -> RSK-001
- `RSK-006` Legal Issue Spotter (SPECIALIST) -> RSK-001
- `RSK-007` Permission Reviewer (SPECIALIST) -> RSK-001
- `RSK-008` Data Classification Officer (SPECIALIST) -> RSK-001
- `RSK-009` External Action Approver (SPECIALIST) -> RSK-001
- `RSK-010` Security Policy Reviewer (SPECIALIST) -> RSK-001

## Default skill pool
risk-review, privacy, permission-check, prompt-injection-defense

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
