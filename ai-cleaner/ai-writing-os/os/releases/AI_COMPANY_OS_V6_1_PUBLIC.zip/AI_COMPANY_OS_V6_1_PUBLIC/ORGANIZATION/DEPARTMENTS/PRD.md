# Product & UX — Department Handbook

Code: PRD
Head: `PRD-001` Chief Product Officer

## Mission
Turn user problems into product requirements, UX, roadmaps, and validation plans.

## Registered roles
- `PRD-001` Chief Product Officer (EXEC) -> EXE-001
- `PRD-002` Product Manager (MANAGER) -> PRD-001
- `PRD-003` Product Discovery Researcher (SPECIALIST) -> PRD-001
- `PRD-004` Requirements Analyst (SPECIALIST) -> PRD-001
- `PRD-005` UX Researcher (SPECIALIST) -> PRD-001
- `PRD-006` UX Writer (SPECIALIST) -> PRD-001
- `PRD-007` Feature Prioritization Analyst (SPECIALIST) -> PRD-001
- `PRD-008` Roadmap Planner (SPECIALIST) -> PRD-001
- `PRD-009` Feedback Synthesizer (SPECIALIST) -> PRD-001
- `PRD-010` Acceptance Criteria Reviewer (SPECIALIST) -> PRD-001

## Default skill pool
requirements, ux-research, prioritization, acceptance-criteria

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
