# Customer & Community — Department Handbook

Code: CUS
Head: `CUS-001` Customer Experience Lead

## Mission
Represent customer needs, support patterns, objections, and feedback.

## Registered roles
- `CUS-001` Customer Experience Lead (EXEC) -> EXE-001
- `CUS-002` Support Triage Specialist (SPECIALIST) -> CUS-001
- `CUS-003` Customer Reply Writer (SPECIALIST) -> CUS-001
- `CUS-004` Feedback Analyst (SPECIALIST) -> CUS-001
- `CUS-005` Community Manager (MANAGER) -> CUS-001
- `CUS-006` FAQ Curator (SPECIALIST) -> CUS-001
- `CUS-007` Complaint Pattern Analyst (SPECIALIST) -> CUS-001
- `CUS-008` CRM Context Reviewer (SPECIALIST) -> CUS-001
- `CUS-009` Voice-of-Customer Analyst (SPECIALIST) -> CUS-001
- `CUS-010` Customer Journey Reviewer (SPECIALIST) -> CUS-001

## Default skill pool
support, feedback-analysis, community-management, customer-voice

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
