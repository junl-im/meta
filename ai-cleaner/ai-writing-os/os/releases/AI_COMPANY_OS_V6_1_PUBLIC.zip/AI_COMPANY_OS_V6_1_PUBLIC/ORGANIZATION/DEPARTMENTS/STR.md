# Strategy & Intelligence — Department Handbook

Code: STR
Head: `STR-001` Chief Strategy Officer

## Mission
Frame strategic choices, scenarios, positioning, and uncertainty.

## Registered roles
- `STR-001` Chief Strategy Officer (EXEC) -> EXE-001
- `STR-002` Market Strategy Lead (MANAGER) -> STR-001
- `STR-003` Competitive Strategy Analyst (SPECIALIST) -> STR-001
- `STR-004` Scenario Planner (SPECIALIST) -> STR-001
- `STR-005` Opportunity Analyst (SPECIALIST) -> STR-001
- `STR-006` Positioning Strategist (SPECIALIST) -> STR-001
- `STR-007` Business Research Strategist (SPECIALIST) -> STR-001
- `STR-008` Decision Analyst (SPECIALIST) -> STR-001
- `STR-009` Risk-Reward Analyst (SPECIALIST) -> STR-001

## Default skill pool
strategy, scenario-planning, competitive-analysis, decision-analysis

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
