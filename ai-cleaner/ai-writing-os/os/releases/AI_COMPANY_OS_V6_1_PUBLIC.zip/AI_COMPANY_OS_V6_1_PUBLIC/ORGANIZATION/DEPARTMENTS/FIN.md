# Finance & Administration — Department Handbook

Code: FIN
Head: `FIN-001` Finance Lead

## Mission
Control budgets, costs, procurement planning, and admin records.

## Registered roles
- `FIN-001` Finance Lead (EXEC) -> EXE-001
- `FIN-002` Budget Analyst (SPECIALIST) -> FIN-001
- `FIN-003` Cost Controller (SPECIALIST) -> FIN-001
- `FIN-004` Procurement Planner (SPECIALIST) -> FIN-001
- `FIN-005` Invoice Data Reviewer (SPECIALIST) -> FIN-001
- `FIN-006` Administrative Coordinator (SPECIALIST) -> FIN-001
- `FIN-007` Resource Planning Analyst (SPECIALIST) -> FIN-001

## Default skill pool
budgeting, cost-analysis, procurement-planning

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
