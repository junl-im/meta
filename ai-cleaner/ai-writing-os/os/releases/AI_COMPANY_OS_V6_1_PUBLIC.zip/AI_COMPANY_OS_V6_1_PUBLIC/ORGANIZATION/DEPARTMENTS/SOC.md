# Social & Community — Department Handbook

Code: SOC
Head: `SOC-001` Head of Social

## Mission
Create short-form/social content and community-facing communication.

## Registered roles
- `SOC-001` Head of Social (EXEC) -> EXE-001
- `SOC-002` Instagram Lead (MANAGER) -> SOC-001
- `SOC-003` Reels Script Writer (SPECIALIST) -> SOC-001
- `SOC-004` Instagram Feed Writer (SPECIALIST) -> SOC-001
- `SOC-005` Social Review Writer (SPECIALIST) -> SOC-001
- `SOC-006` Social SEO Specialist (SPECIALIST) -> SOC-001
- `SOC-007` Hook Specialist (SPECIALIST) -> SOC-001
- `SOC-008` Engagement Copywriter (SPECIALIST) -> SOC-001
- `SOC-009` Community Caption Writer (SPECIALIST) -> SOC-001
- `SOC-010` Short-form Editor (SPECIALIST) -> SOC-001
- `SOC-011` Social Trend Analyst (SPECIALIST) -> SOC-001
- `SOC-012` Platform QA Reviewer (SPECIALIST) -> SOC-001
- `SOC-013` Social Intake & Truth Auditor (SPECIALIST) -> SOC-002
- `SOC-014` Instagram Audience Psychology Analyst (SPECIALIST) -> SOC-002
- `SOC-015` Hook Challenger A (SPECIALIST) -> SOC-002
- `SOC-016` Hook Challenger B (SPECIALIST) -> SOC-002
- `SOC-017` Instagram Format Writer (SPECIALIST) -> SOC-002
- `SOC-018` Instagram Detail & Value Writer (SPECIALIST) -> SOC-002
- `SOC-019` Instagram Engagement & CTA Strategist (SPECIALIST) -> SOC-002
- `SOC-020` Instagram Mobile Naturalness Editor (SPECIALIST) -> SOC-002
- `SOC-021` Instagram Fact Review Ethics QA (SPECIALIST) -> SOC-002
- `SOC-022` Senior Social Synthesis Editor (MANAGER) -> SOC-001

## Default skill pool
shortform-writing, instagram, hook-writing, social-qa, fact-check, evidence-ledger, audience-segmentation, purchase-journey, instagram-reels, natural-korean, cta-writing, instagram-feed, storytelling, seo, conversion-copy, brand-voice, health-claims-safety, ad-disclosure-check

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
