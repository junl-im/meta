# Commerce & Partnerships — Department Handbook

Code: COM
Head: `COM-001` Commerce Director

## Mission
Shape offers, merchandising, partnerships, purchase journeys, and commercial copy.

## Registered roles
- `COM-001` Commerce Director (EXEC) -> EXE-001
- `COM-002` Product Positioning Specialist (SPECIALIST) -> COM-001
- `COM-003` Offer Strategist (SPECIALIST) -> COM-001
- `COM-004` Product Comparison Analyst (SPECIALIST) -> COM-001
- `COM-005` Merchandising Planner (SPECIALIST) -> COM-001
- `COM-006` Partnership Researcher (SPECIALIST) -> COM-001
- `COM-007` Affiliate Content Planner (SPECIALIST) -> COM-001
- `COM-008` Purchase Journey Analyst (SPECIALIST) -> COM-001
- `COM-009` Pricing Context Analyst (SPECIALIST) -> COM-001
- `COM-010` Commerce QA Reviewer (SPECIALIST) -> COM-001

## Default skill pool
product-positioning, comparison, offer-design, commerce-copy

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
