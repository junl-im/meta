# Executive Office — Department Handbook

Code: EXE
Head: `EXE-001` AI CEO

## Mission
Set company direction, success criteria, priorities, and final tradeoffs.

## Registered roles
- `EXE-001` AI CEO (EXEC) -> HUMAN_OWNER
- `EXE-002` Executive Decision Analyst (SPECIALIST) -> EXE-001
- `EXE-003` Portfolio Prioritization Advisor (SPECIALIST) -> EXE-001
- `EXE-004` Executive Briefing Officer (SPECIALIST) -> EXE-001
- `EXE-005` Business Model Advisor (SPECIALIST) -> EXE-001
- `EXE-006` Strategic Tradeoff Reviewer (SPECIALIST) -> EXE-001

## Default skill pool
executive-briefing, decision-analysis, prioritization

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
