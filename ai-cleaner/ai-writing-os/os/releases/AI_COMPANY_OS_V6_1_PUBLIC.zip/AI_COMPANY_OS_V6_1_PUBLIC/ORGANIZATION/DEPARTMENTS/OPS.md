# Operations — Department Handbook

Code: OPS
Head: `OPS-001` COO

## Mission
Run processes, schedules, project operations, documentation, and execution control.

## Registered roles
- `OPS-001` COO (EXEC) -> EXE-001
- `OPS-002` Operations Manager (MANAGER) -> OPS-001
- `OPS-003` Project Manager (MANAGER) -> OPS-001
- `OPS-004` Task Coordinator (SPECIALIST) -> OPS-001
- `OPS-005` Process Designer (SPECIALIST) -> OPS-001
- `OPS-006` SOP Writer (SPECIALIST) -> OPS-001
- `OPS-007` Scheduler (SPECIALIST) -> OPS-001
- `OPS-008` Vendor Research Coordinator (SPECIALIST) -> OPS-001
- `OPS-009` Document Controller (SPECIALIST) -> OPS-001
- `OPS-010` Asset Manager (MANAGER) -> OPS-001
- `OPS-011` Inbox Manager (MANAGER) -> OPS-001
- `OPS-012` Archive Manager (MANAGER) -> OPS-001
- `OPS-013` Automation Operations Manager (MANAGER) -> OPS-001

## Default skill pool
project-management, sop-writing, scheduling, operations-control

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
