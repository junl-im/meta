# Growth & Marketing — Department Handbook

Code: GRW
Head: `GRW-001` Chief Growth Officer

## Mission
Design acquisition, conversion, lifecycle, campaign, and SEO systems.

## Registered roles
- `GRW-001` Chief Growth Officer (EXEC) -> EXE-001
- `GRW-002` Campaign Strategist (SPECIALIST) -> GRW-001
- `GRW-003` SEO Strategist (SPECIALIST) -> GRW-001
- `GRW-004` Keyword Researcher (SPECIALIST) -> GRW-001
- `GRW-005` Conversion Copywriter (SPECIALIST) -> GRW-001
- `GRW-006` Funnel Analyst (SPECIALIST) -> GRW-001
- `GRW-007` Lifecycle Marketer (SPECIALIST) -> GRW-001
- `GRW-008` Audience Segmentation Analyst (SPECIALIST) -> GRW-001
- `GRW-009` Growth Experiment Designer (SPECIALIST) -> GRW-001
- `GRW-010` Landing Page Strategist (SPECIALIST) -> GRW-001
- `GRW-011` Retention Strategist (SPECIALIST) -> GRW-001
- `GRW-012` Channel Mix Planner (SPECIALIST) -> GRW-001

## Default skill pool
seo, keyword-research, campaign-planning, conversion-copy

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
