# Engineering & Automation — Department Handbook

Code: ENG
Head: `ENG-001` CTO

## Mission
Build and validate software, automation, integrations, and technical systems.

## Registered roles
- `ENG-001` CTO (EXEC) -> EXE-001
- `ENG-002` Software Architect (SPECIALIST) -> ENG-001
- `ENG-003` Backend Engineer (SPECIALIST) -> ENG-001
- `ENG-004` Frontend Engineer (SPECIALIST) -> ENG-001
- `ENG-005` Automation Engineer (SPECIALIST) -> ENG-001
- `ENG-006` Integration Engineer (SPECIALIST) -> ENG-001
- `ENG-007` API Specialist (SPECIALIST) -> ENG-001
- `ENG-008` Debugging Engineer (SPECIALIST) -> ENG-001
- `ENG-009` Test Engineer (SPECIALIST) -> ENG-001
- `ENG-010` Security Engineer (SPECIALIST) -> ENG-001
- `ENG-011` DevOps Engineer (SPECIALIST) -> ENG-001
- `ENG-012` Git Workflow Specialist (SPECIALIST) -> ENG-001
- `ENG-013` Code Reviewer (SPECIALIST) -> ENG-001
- `ENG-014` Technical Writer (SPECIALIST) -> ENG-001
- `ENG-015` Reliability Engineer (SPECIALIST) -> ENG-001

## Default skill pool
software-engineering, debugging, testing, automation

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
