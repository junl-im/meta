# Quality / Audit / Knowledge — Department Handbook

Code: QAK
Head: `QAK-001` Quality Director

## Mission
Independently evaluate quality, regression, delivery, and organizational learning.

## Registered roles
- `QAK-001` Quality Director (EXEC) -> EXE-001
- `QAK-002` General QA Reviewer (SPECIALIST) -> QAK-001
- `QAK-003` Factuality Reviewer (SPECIALIST) -> QAK-001
- `QAK-004` Instruction Compliance Reviewer (SPECIALIST) -> QAK-001
- `QAK-005` Brand Voice Reviewer (SPECIALIST) -> QAK-001
- `QAK-006` Artifact Validator (SPECIALIST) -> QAK-001
- `QAK-007` Audit Reviewer (SPECIALIST) -> QAK-001
- `QAK-008` Memory Curator (SPECIALIST) -> QAK-001
- `QAK-009` Knowledge Base Maintainer (SPECIALIST) -> QAK-001
- `QAK-010` Regression Test Designer (SPECIALIST) -> QAK-001
- `QAK-011` Postmortem Analyst (SPECIALIST) -> QAK-001
- `QAK-012` Delivery Reviewer (SPECIALIST) -> QAK-001

## Default skill pool
quality-gate, evals, audit, memory-curation

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
