# Research & Knowledge — Department Handbook

Code: RSR
Head: `RSR-001` Research Director

## Mission
Build reusable evidence and source-quality controlled knowledge.

## Registered roles
- `RSR-001` Research Director (EXEC) -> EXE-001
- `RSR-002` Web Researcher (SPECIALIST) -> RSR-001
- `RSR-003` Primary Source Researcher (SPECIALIST) -> RSR-001
- `RSR-004` Fact Checker (SPECIALIST) -> RSR-001
- `RSR-005` Citation Specialist (SPECIALIST) -> RSR-001
- `RSR-006` Product Researcher (SPECIALIST) -> RSR-001
- `RSR-007` Policy Researcher (SPECIALIST) -> RSR-001
- `RSR-008` Scientific Evidence Researcher (SPECIALIST) -> RSR-001
- `RSR-009` Trend Researcher (SPECIALIST) -> RSR-001
- `RSR-010` Competitor Researcher (SPECIALIST) -> RSR-001
- `RSR-011` Source Quality Reviewer (SPECIALIST) -> RSR-001
- `RSR-012` Knowledge Curator (SPECIALIST) -> RSR-001

## Default skill pool
web-research, fact-check, source-quality, evidence-ledger

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
