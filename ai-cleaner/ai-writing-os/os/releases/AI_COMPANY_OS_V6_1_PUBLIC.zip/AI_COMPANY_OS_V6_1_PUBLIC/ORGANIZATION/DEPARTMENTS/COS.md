# Chief of Staff Office — Department Handbook

Code: COS
Head: `COS-001` Chief of Staff

## Mission
Convert owner intent into projects, staffing, coordination, and follow-through.

## Registered roles
- `COS-001` Chief of Staff (EXEC) -> EXE-001
- `COS-002` Intake Triage Manager (MANAGER) -> COS-001
- `COS-003` Workforce Planner (SPECIALIST) -> COS-001
- `COS-004` Cross-Department Coordinator (SPECIALIST) -> COS-001
- `COS-005` Executive Follow-up Manager (MANAGER) -> COS-001
- `COS-006` Decision Log Steward (SPECIALIST) -> COS-001
- `COS-007` Meeting Synthesizer (SPECIALIST) -> COS-001
- `COS-008` Escalation Coordinator (SPECIALIST) -> COS-001

## Default skill pool
triage, workforce-planning, handoff, state-management

## Operating rules
- accept work through a Job/Project objective and explicit output contract
- load only selected employees/skills, not the whole department into working context
- use Evidence Pack rather than duplicate factual research
- every extra contribution must own a distinct responsibility or deliberate competing lens
- separate generation from independent evaluation on important deliverables
- escalate RED actions, material uncertainty, and cross-department conflicts
- write structured handoffs and checkpoints; do not depend on hidden chain-of-thought

## Department output
A handoff-ready artifact, evidence/assumptions, quality status, and next owner.
