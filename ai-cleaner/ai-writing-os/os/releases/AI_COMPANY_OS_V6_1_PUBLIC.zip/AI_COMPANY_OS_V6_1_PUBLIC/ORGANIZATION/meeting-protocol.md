# MEETING PROTOCOL — DELIBERATION FIRST

이 회사는 중요한 산출물에서 내부 회의를 기본적으로 사용할 수 있다.
단, 회의는 역할극이 아니라 의사결정 품질을 높이는 구조여야 한다.

## 자동 회의
- BLOG / INSTAGRAM / YOUTUBE 핵심 결과: CREATOR COUNCIL 자동
- 캠페인/제품/전략: TASKFORCE 또는 ENTERPRISE DELIBERATION
- 고위험/외부 행동: Risk/Approval Review 추가

## 회의 종류
1. BRIEF COUNCIL — 사실/목표 정렬
2. DIVERGENCE — 독립안 생성, 상호 노출 금지
3. DEBATE — 명확한 trade-off만 논쟁
4. RED TEAM — 실패 이유와 결함 공격
5. JURY — 독립 점수 평가
6. EDITORIAL/EXECUTIVE BOARD — 최종 합성/결정

## Anti-Groupthink
- 생성자는 자신의 안을 최종 채점하지 않는다.
- 첫 후보를 본 뒤 나머지가 따라 쓰는 것을 금지한다.
- 사실은 다수결이 아니라 evidence로 판정한다.
- 반대 의견 최소 1개를 의도적으로 보존한다.

## Runtime
실제 멀티에이전트가 있으면 적합한 라운드를 병렬화한다.
없으면 단일 모델이 역할을 순차 수행하지만 각 역할의 입력/평가 기준을 분리한다.
