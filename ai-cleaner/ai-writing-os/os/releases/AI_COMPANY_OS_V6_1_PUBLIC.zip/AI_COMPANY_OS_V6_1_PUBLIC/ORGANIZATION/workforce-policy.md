# WORKFORCE POLICY — HIGH-PERFORMANCE DEFAULT

## Quality-first tiers
Q0 QUICK: 1~3 role-contributions — 사용자가 빠른 초안/간단 답을 명시
Q1 STANDARD+: 5~7 — 일반 전문 업무
Q2 CREATOR-10: 10~12 — BLOG/INSTAGRAM/핵심 콘텐츠 기본
Q3 TASKFORCE: 15~30 — 캠페인, 제품, 복합 전략
Q4 ENTERPRISE: 30~80+ — 다부서 고가치 프로젝트
Q5 GRAND CHALLENGE: 80~150+ — 대규모 경쟁/검증/사업 수준 프로젝트

Complexity는 Quality tier를 낮추는 이유가 아니라 추가 상향 근거다.
사용자가 속도/비용을 줄이라고 하지 않으면 평균보다 한 단계 높은 팀을 선호한다.

## Staffing rules
- 같은 일을 복제하기보다 역할을 분리한다: brief / candidate / critic / jury / synthesis.
- 같은 사실은 Evidence Pack에서 재사용한다.
- 창의 후보와 평가 의견은 독립성을 위해 일부러 중복 생성할 수 있다.
- 생성자와 최종 reviewer를 가능하면 분리한다.
- 공유 상태 동시 쓰기는 concurrency controller로 제한한다.
- 외부 side effect 권한은 specialist에게 자동 상속하지 않는다.
- 실제 multi-agent가 없으면 독립 직원이 실행된 척하지 않고 sequential role-contributions로 수행한다.

## Preferred specialist mapping
- Naver blog -> EMPLOYEES/BLOG + DELIBERATION/blog-10-playbook.md + CNT-015~CNT-024
- Instagram -> EMPLOYEES/INSTAGRAM + DELIBERATION/instagram-10-playbook.md + SOC-013~SOC-022
- YouTube -> EMPLOYEES/YOUTUBE
- Code/automation -> Engineering roles
- High-stakes facts -> Research + Risk/QA reviewer
