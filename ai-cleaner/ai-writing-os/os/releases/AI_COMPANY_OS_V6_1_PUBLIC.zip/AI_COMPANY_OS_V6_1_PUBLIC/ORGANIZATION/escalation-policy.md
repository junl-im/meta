# ESCALATION POLICY

Specialist → Team Lead: 전문 범위 밖 / 충돌 / 입력 결손
Team Lead → Department Head: 범위/우선순위/부서 간 충돌
Department Head → Chief of Staff: 자원/의존성/프로젝트 범위
Chief of Staff → CEO: 전략/중대한 trade-off
CEO → Human Owner: 높은 위험, 사용자만 아는 사실, 외부 행동 승인
