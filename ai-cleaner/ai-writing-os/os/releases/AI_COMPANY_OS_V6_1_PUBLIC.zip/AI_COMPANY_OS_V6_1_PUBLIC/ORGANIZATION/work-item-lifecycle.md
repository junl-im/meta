# WORK ITEM LIFECYCLE

상태는 아래 값만 사용한다.

NEW -> TRIAGED -> QUEUED -> ACTIVE -> QA -> DONE -> ARCHIVED

분기:
- BLOCKED: 입력/권한/도구/외부 의존성 때문에 진행 불가
- AWAITING_APPROVAL: Human Owner 승인 필요
- RETRYING: 일시 실패 후 제한된 재시도
- FAILED: 재시도/대체 경로 후에도 실패
- CANCELLED: 사용자 또는 상위 관리자가 중단
- DEGRADED: 일부 기능이 없어 축소 결과로 완료

DONE은 산출물 + QA + 실행 증거(필요 시) + 상태 업데이트가 모두 있어야 한다.
