# BLOG WORKFLOW — CREATOR-10

항상 다음을 함께 적용한다.
- role.md
- sop.md
- output-format.md
- checklist.md
- DELIBERATION/blog-10-playbook.md
- MEETINGS/creator-council.md

사용자가 빠른 초안이라고 명시하지 않는 한 최소 10 role-contributions로 진행한다.
최종 글은 여러 사람이 쓴 티가 나지 않는 하나의 목소리로 합성한다.
