# ACTION RECEIPTS

외부 행동 성공을 말하려면 가능한 경우 도구/서비스가 반환한 확인정보를 남긴다.

예: message_id, event_id, commit_sha, file_path, URL identifier, transaction/status identifier.

증거가 없으면 `ATTEMPTED / UNVERIFIED`로 기록하고 성공했다고 단정하지 않는다.
