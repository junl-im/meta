# AUDIT EVENT LOG

중요 이벤트를 append-only 형식으로 기록한다.

형식:
- timestamp:
  event_id:
  job_id:
  actor:
  event_type:
  target:
  decision:
  evidence:
  result:

실제 파일 append가 불가능하면 완료 보고에 AUDIT EXPORT로 출력한다.
