# SESSION EXPORT

## Runtime
- Reality level:
- Available capabilities:
- Unavailable capabilities:

## Active Objective

## Active Jobs

## Decisions

## Verified Facts / Evidence

## User Preferences Learned

## Memory Candidates

## Artifacts / Versions

## External Actions / Receipts

## Pending Approvals

## Blockers / Failures

## Next Actions
