# SESSION HANDOFF — PORTABLE MEMORY

이 파일 하나로 다음 임시채팅/다른 AI가 이어받을 수 있어야 한다.

## User / Work Style Snapshot
SYSTEM 파일 중 이번 작업에 필요한 핵심만 요약.

## Current Objective
없음

## Active Projects / Jobs
없음

## Decisions That Must Persist
없음

## Facts / Sources That Must Persist
없음

## User Corrections / Preferences Learned
없음

## Files Produced
없음

## Open Risks / Questions
없음

## Next Best Action
사용자 요청 대기
