# WORK QUEUE

상태: INTAKE → PLANNED → ACTIVE → REVIEW → BLOCKED/WAITING → DONE → ARCHIVED

Priority: P0 critical / P1 important / P2 normal / P3 backlog.
한 번에 너무 많은 ACTIVE JOB을 만들지 않는다.
