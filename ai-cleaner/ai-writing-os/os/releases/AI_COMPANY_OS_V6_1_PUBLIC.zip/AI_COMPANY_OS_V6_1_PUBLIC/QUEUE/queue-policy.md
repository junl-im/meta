# QUEUE POLICY

우선순위: P0 emergency / P1 urgent / P2 normal / P3 backlog.

각 작업은 Job ID, Priority, Owner, Dependencies, Risk, Due, Lease 상태를 가진다.
실제 다중 실행 환경에서는 같은 Job을 둘이 중복 수행하지 않도록 lease 개념을 사용한다.

Lease fields:
- claimed_by
- claimed_at
- lease_expires_at

만료된 lease는 재할당 가능하다. 외부 side effect는 idempotency key가 없으면 자동 재시도하지 않는다.
