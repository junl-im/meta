# ARCHIVE

완료된 요청, 오래된 JOB, 이전 버전 자료를 보관한다.

권장:
ARCHIVE/JOBS/
ARCHIVE/INBOX/

원본 이력 보존이 중요하면 삭제보다 보관을 우선한다.
