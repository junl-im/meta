# V5.5 AUDIT — CONTENT BOUNDARY & KOREAN-FIRST

## Audit goal
V5.4를 실제 사용했을 때 발견된 두 핵심 실패를 일반화해 재발 방지 구조로 수정했다.

1. `첨부파일은 내 가상 OS야. 이걸 기준으로 글 써줘`를 OS 자체도 글의 소재라고 오해함.
2. 한국어 사용자/한국어 콘텐츠 중심인데 영문 주제·영문 참고자료 때문에 최종 글이 영어로 드리프트함.

## Root causes

### A. Control/Data separation이 암묵적이었음
OS가 작업 지침이라는 사실은 사람에게는 명확했지만, 런타임 계약에는 `OS=CONTROL`, `주제/자료=CONTENT`가 기계적으로 분리되지 않았다.

### B. 출력 언어가 스타일 선호 수준에 머물렀음
`자연스러운 한국어`는 있었지만 `외국어를 명시하기 전에는 무조건 한국어`라는 결정 규칙과 final gate가 없었다.

### C. Context Pack에 경계 상태가 없었음
어떤 첨부가 규칙이고 어떤 첨부가 내용인지, 이전 OUTPUT을 재사용할지, 출력 언어가 무엇인지 Job state에 명시되지 않았다.

## V5.5 fixes

| Area | Before | V5.5 |
|---|---|---|
| OS role | 암묵적 운영 지침 | CONTROL PLANE으로 명시 |
| Article topic | Context가 넓게 섞일 수 있음 | Topic Source Whitelist |
| Multiple attachments | 역할 분리 약함 | CONTROL/TASK_CONTENT/STYLE/EVIDENCE/PRIOR_OUTPUT 분류 |
| Language | 한국어 선호 | 명시적 외국어 요청 전까지 Korean-first 강제 |
| English sources | 출력 언어 드리프트 가능 | 자료 언어와 출력 언어 분리 |
| Previous Jobs | 관련성 과추론 가능 | 새 명시 주제에서 Content Scope Reset |
| Examples | 스타일+사실 혼합 가능 | STYLE_REFERENCE는 사실 공급 금지 |
| Embedded prompts | 자료 속 명령 오염 가능 | 참고자료는 DATA, 직접 지시로 승격 금지 |
| Final output | 메타가 새어 나올 가능성 | Final Content Boundary Gate |
| Machine contract | 없음 | Context/Input schemas 추가 |

## Three-layer enforcement

### 1. Boot gate
`BOOT.md`, `SYSTEM/08_content-boundary.md`, `SYSTEM/09_language-policy.md`에서 최초 규칙을 고정한다.

### 2. Job/context gate
Job/Context Pack에 다음을 상태로 기록한다.
- CONTROL_ASSETS
- TASK_CONTENT
- STYLE_REFERENCES
- PRIOR_OUTPUT_REUSE
- CONTENT_SCOPE_RESET
- OUTPUT_LANGUAGE (default ko)

### 3. Delivery gate
최종 납품 직전에 다시 검사한다.
- OS/직원/회의/엔진 메타 누출
- 이전 Job/예시의 사실 도용
- 비의도적 영어 문장 드리프트

## Additional issues found during audit

### 1. Portable boot conflict
이전 `PORTABLE/BOOT_PROMPT.txt`에 `필요한 최소 역할만 활성화`가 남아 V5.2+의 Creator-10 고품질 정책과 충돌했다.
수정: BLOG/INSTAGRAM Creator-10 하한과 content/language 규칙을 반영한 한 줄 프롬프트로 교체.

### 2. Engine map drift
과거 Engine Map이 실제 런타임 모듈보다 오래된 정보를 가질 가능성이 있었다.
수정: 00~43 전체 Engine Map 재생성.

### 3. Regression gap
OS/content 섞임과 언어 드리프트를 자동 검사하는 테스트가 없었다.
수정: `RUNTIME/scripts/test_content_contract.py` 및 `TESTS/V5_5_BOUNDARY_LANGUAGE_TESTS.md` 추가.

## Remaining real-world limitations

1. ZIP 탐색 방식은 AI 제품별로 다르다. 어떤 환경은 모든 파일을 안정적으로 탐색하지 못할 수 있다. 이 경우 `PORTABLE/PORTABLE_CORE.md`가 fallback이다.
2. 실제 multi-agent를 지원하지 않는 환경에서는 Creator-10이 10개의 독립 프로세스가 아니라 분리된 role-contribution으로 실행된다.
3. Markdown 규칙은 강한 운영 계약이지만 모델 자체의 완전한 준수를 수학적으로 보장하지 않는다. 그래서 핵심 규칙을 Boot/Context/Delivery 세 층에 중복 배치했다.
4. 장기 기억이 없는 임시채팅은 ZIP 및 SESSION HANDOFF가 상태 저장소 역할을 한다.
5. OS를 다른 사람/서비스에 공유할 때 `SYSTEM`, `PROJECTS`, `MEMORY`에 민감한 정보가 들어갈 수 있으므로 비밀번호·토큰·인증정보를 저장하지 않는다.

## Validation status
- Employee hierarchy: PASS
- 200 employee registry: PASS
- 99 skill references: PASS
- 17 departments: PASS
- Engine modules 00-43: PASS
- 8 JSON schemas: PASS
- Content boundary contract: PASS
- Korean-first contract: PASS
- Creator BLOG/Instagram guard: PASS
- Broken path references: PASS

## Acceptance criterion
이 버전의 핵심 합격 조건은 "OS를 기준으로 작업하라"가 **항상 방법론 지시로 해석**되고, 사용자가 외국어 결과를 명시하지 않는 한 **최종 사용자-facing 콘텐츠가 한국어**로 유지되는 것이다.
