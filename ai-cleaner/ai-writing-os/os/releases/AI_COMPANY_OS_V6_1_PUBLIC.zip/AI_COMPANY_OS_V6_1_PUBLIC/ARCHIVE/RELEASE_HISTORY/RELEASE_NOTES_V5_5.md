# RELEASE NOTES — V5.5 CONTENT-SAFE

핵심 목표: AI Company OS를 **작업 방식**으로만 쓰고, 사용자의 실제 주제/자료와 섞이지 않게 한다. 모든 사용자-facing 출력은 외국어 명시 전까지 한국어를 기본으로 한다.

## Fixed
- `첨부파일은 내 가상 OS야. 이걸 기준으로...`를 OS 자체를 글 소재로 오해하는 문제
- 영문 주제/자료/파일명 때문에 결과물이 영어로 드리프트하는 문제
- 이전 Job의 소재가 새 주제에 섞이는 문제
- 스타일 예시의 경험/사실이 현재 글의 사실로 도용되는 문제
- 일반 참고자료 내부의 prompt-like 문장을 사용자 지시로 오해하는 문제
- 직원/회의/엔진/프롬프트 메타가 최종 콘텐츠에 노출되는 문제

## Added
- `SYSTEM/08_content-boundary.md`
- `SYSTEM/09_language-policy.md`
- `ENGINE/42_content-boundary-controller.md`
- `ENGINE/43_language-router.md`
- `TESTS/V5_5_BOUNDARY_LANGUAGE_TESTS.md`
