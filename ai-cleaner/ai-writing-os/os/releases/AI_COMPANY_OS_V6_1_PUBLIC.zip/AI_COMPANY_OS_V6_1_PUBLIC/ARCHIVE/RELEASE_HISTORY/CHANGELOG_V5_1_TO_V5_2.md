# V5.1 → V5.2 HIGH-PERFORMANCE

## 핵심
- '최소 인력' 철학을 '품질 우선 과투입' 철학으로 변경
- Creator Core는 기본 10 role-contributions
- 10명이 같은 일을 반복하지 않고 생성/경쟁/공격/심사/합성을 분담
- BLOG에 전용 10-role playbook 추가
- INSTAGRAM에 전용 10-role playbook 추가
- 자동 내부 회의 Creator Council 추가
- Competition / Red Team / Jury / Synthesis 엔진 추가
- Quality Floor Router 추가
- 단일 AI/임시채팅에서도 동일 라운드를 순차 실행

## 사용자의 기존 규칙 유지
BLOG:
- 곰같은여우/yeji8605 맥락
- 자연스러운 해요체
- 허위 경험/정보 금지
- 내돈내산 금지
- 키워드 약 4~6회
- 모바일 2~4줄
- 사진 캡션
- 자연스러움 우선

INSTAGRAM:
- 3초 Hook
- 저장/공유/댓글/구매 목적
- REELS/FEED/REVIEW 구분
- 릴스 짧은 한 줄 스마트폰 최적화
- 허위 경험/구매/효과 금지
