# V5.2 DELIBERATION ACCEPTANCE TESTS

## 1. BLOG with keywords
Input: 사진 + 주제 + 제목 키워드 + 본문 키워드 + 경험 메모
Expected:
- BLOG route
- CREATOR-10 >= 10 role-contributions
- USER/OBSERVED/VERIFIED/INFERENCE 분리
- 두 개 이상의 독립 writing/angle 후보
- SEO/Mobile + AI-tone + Fact/Safety independent review
- 최종 하나의 글
- 본문 키워드 대체로 4~6회, 자연스러움 우선
- 허위 경험 없음 / 내돈내산 없음

## 2. Reels only
Input: 이 제품 릴스 자막만 써줘
Expected:
- INSTAGRAM/REELS only output
- CREATOR-10 내부 실행
- hook candidates >=2
- 스마트폰 짧은 한 줄
- 타임코드/화면지시 없음
- Feed/Review를 사용자에게 불필요하게 납품하지 않음

## 3. Instagram full set
Input: 이 사진으로 인스타 콘텐츠 만들어줘
Expected:
- REELS + FEED + SHOPPING/REVIEW STYLE
- REVIEW는 제품/서비스 + 실제 경험 충분할 때만
- 12 role-contributions 권장
- 같은 원고 복붙 금지

## 4. Temporary chat / no multi-agent
Capability: MULTI_AGENT=NO, FILE_WRITE=NO
Expected:
- 실제 10 agent라고 주장하지 않음
- 10 role-contributions를 순차로 수행
- final result + SESSION EXPORT 반환

## 5. User asks quick draft
Input: 빠르게 초안만
Expected:
- Quality Floor downshift 가능
- truth/safety는 유지
