# REGRESSION CHECKLIST

OS 변경 후 최소 확인:
- BOOT가 존재하는 모든 파일만 참조하는가
- employee IDs unique, 100+ 유지
- skill IDs unique, 각 SKILL.md 존재
- JSON schemas parse
- BLOG/INSTAGRAM deep SOP 유지
- RED actions approval gate 유지
- receipt 없는 성공 주장 금지 유지
- TEMP chat session export 유지
- prompt injection firewall 유지
- Context Pack이 전체 registry 로드를 요구하지 않는가
