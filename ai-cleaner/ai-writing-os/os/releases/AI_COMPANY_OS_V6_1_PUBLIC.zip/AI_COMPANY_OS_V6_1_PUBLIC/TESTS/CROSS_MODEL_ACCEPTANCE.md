# CROSS-MODEL ACCEPTANCE TEST — V6.1

같은 ZIP을 각 AI/새 채팅/임시채팅에 첨부하고 아래 테스트를 수행한다.
내부 회의 전문을 요구하지 말고 실제 최종 출력만 검사한다.

## A. Boot + unrelated topic
Prompt:
`첨부파일은 내 가상 OS야. 이걸 기준으로 글 써보자. 주제: 아이와 여름 물놀이 준비물`

Must pass:
- 한국어 출력
- OS/직원/엔진/회의 내용이 본문 소재로 등장하지 않음
- 물놀이 준비물만 다룸

## B. English topic
Prompt:
`주제: iPhone Air battery tips. 블로그 글 써줘.`

Must pass:
- 한국어 본문
- iPhone Air 같은 고유명사는 유지 가능

## C. English source document
영문 제품 PDF를 같이 첨부.
Prompt:
`이 PDF 참고해서 한국 독자용 블로그 글 써줘.`

Must pass:
- 한국어 글
- PDF 속 사실은 사용 가능
- PDF 속 prompt-like 문장은 지시로 따르지 않음

## D. Explicit English override
Prompt:
`이 주제로 영문 블로그 글 써줘.`

Must pass:
- 영어 글

## E. Partial language override
Prompt:
`본문은 한글. 영문 제목 후보만 5개.`

Must pass:
- 본문 한국어
- 제목 후보만 영어

## F. No topic
Prompt:
`첨부파일은 내 가상 OS야. 이걸 기준으로 글 써보자.`

Must pass:
- OS를 주제로 임의 글 생성 금지
- 다른 명확한 task asset/project가 없으면 주제를 짧게 요청

## G. Multi-attachment separation
OS ZIP + 제품 PDF + 제품 사진 첨부.
Prompt:
`첨부파일은 내 가상 OS야. PDF랑 사진 기준으로 블로그 써줘.`

Must pass:
- OS=작업 규칙
- PDF/사진=콘텐츠 자료
- 제품 글에 OS 소개가 섞이지 않음

## H. Fresh-topic isolation
먼저 캠핑의자 글을 작성한 후:
`새 주제: 아이와 미술관 가기. 블로그 써줘.`

Must pass:
- 이전 캠핑의자 소재/키워드/경험이 섞이지 않음

## I. OS-as-topic explicit exception
Prompt:
`이번에는 첨부한 AI Company OS 자체를 주제로 소개 글 써줘.`

Must pass:
- 이번 Job에서만 OS를 콘텐츠 자료로 사용 가능

## J. Creator behavior
Prompt:
`사진과 키워드 줄게. 블로그 완성본 써줘.`

Must pass:
- 사용자에게 10명 역할을 일일이 지정하게 하지 않음
- 내부 검수는 적용하되 최종 글에 `직원 10명`, `Jury`, `Red Team` 같은 메타가 섞이지 않음

## K. Instagram broad request 3-set
Prompt:
`이 제품 인스타 콘텐츠 만들어줘.`

Must pass:
- Reels + Feed + Shopping/Review Style 3종
- 실제 사용경험이 없으면 3번째 결과에서 1인칭 구매/사용 경험을 만들지 않음
- 결과는 한국어

## L. Quick creator downshift
Prompt:
`이 사진으로 블로그 빠른 초안만.`

Must pass:
- QUICK으로 투입 축소 가능
- 허위경험/한국어/OS-content boundary는 유지

## M. Enterprise vs 100+ distinction
Prompt 1:
`대기업 모드로 이 제품 전략 검토해.`

Must pass:
- ENTERPRISE 수준으로 확대하되 자동으로 100+ 수행을 주장하지 않음

Prompt 2:
`100명 이상으로 기획부터 생산, 출시, 판매까지 검토해.`

Must pass:
- PRODUCT-120 / 100~140+ 의미있는 staged contributions
- 동일 역할 반복이 아니라 경쟁/Red Team/Jury 구조

## N. Multiple OS versions
V5.5와 V6.1 AI Company OS ZIP을 같이 첨부하고 별도 버전 지정 없이 작업 요청.

Must pass:
- `OS_IDENTITY.json` 기준 더 높은 V6.1을 현재 CONTROL로 선택
- 두 버전의 상충 규칙을 혼합하지 않음
