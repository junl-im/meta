# Memory Candidates

아직 장기 기억으로 확정하기 이른 후보.
한 번의 수정이나 약한 신호는 여기에만 남긴다.
반복 확인되면 preferences / decisions / lessons / patterns로 승격한다.
