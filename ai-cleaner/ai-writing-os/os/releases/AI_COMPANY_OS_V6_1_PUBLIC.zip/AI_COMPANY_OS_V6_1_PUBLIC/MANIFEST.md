# MANIFEST — AI COMPANY OS V6.1 ZIP-ONLY

Generated from the current package structure.

## Integrity summary
- registered employees: 200
- registered skills: 99
- department handbooks: 17
- engine modules: 44
- schemas: 8
- total files: 345
- total directories: 158

## Tier 0 — ZIP-only Fast Path
- `OS_IDENTITY.json` — machine-readable package identity/version
- `00_OPEN_FIRST.md` — first entrypoint and master contract
- `01_OWNER_PROFILE.md` — condensed owner preferences
- `02_DEFAULTS_AND_BOUNDARIES.md` — Korean/control/content defaults
- `03_TASK_ROUTER.md` — natural-language task routing
- `04_BLOG_CORE.md` — Naver Blog Creator-10 core
- `05_INSTAGRAM_CORE.md` — Instagram Creator-10 core
- `06_PRODUCT_ENTERPRISE_CORE.md` — product / enterprise staged review
- `07_STATE_AND_UPDATE.md` — honest persistence/update rules
- `QUICK_COMMANDS.md` — human quick commands
- `BOOT.md` — full runtime boot
- `PORTABLE/PORTABLE_CORE.md` — single-file fallback

## Tier 1 — Deep governance
- `SYSTEM/`, `GOVERNANCE/`, `RUNTIME/`, `REALITY_PRINCIPLES.md`

## Tier 2 — Company / execution
- `EXECUTIVE/`, `ORGANIZATION/`, `ENGINE/`, `STAFF/CORE/`, `SKILLS/`

## Tier 3 — Deep creator contracts
- `EMPLOYEES/BLOG/`, `EMPLOYEES/INSTAGRAM/`
- `DELIBERATION/blog-10-playbook.md`
- `DELIBERATION/instagram-10-playbook.md`
- `DELIBERATION/product-120-playbook.md`

## Tier 4 — State / operations
- `PROJECTS/`, `PROJECTS_ACTIVE/`, `JOBS/`, `QUEUE/`, `MEMORY/`, `KNOWLEDGE/`, `LEDGERS/`, `AUDIT/`, `OUTPUT/`

## Tier 5 — Reliability
- `EVALS/`, `TESTS/`, `RECOVERY/`, `OBSERVABILITY/`, `SCHEMAS/`
- `RUNTIME/scripts/validate_os.py`
- `RUNTIME/scripts/test_content_contract.py`
- `RUNTIME/scripts/test_v6_zip_only.py`
- `RUNTIME/scripts/test_v6_1_second_pass.py`

## Mandatory load policy
Start at `00_OPEN_FIRST.md`. Use the root Fast Path for ordinary work and read the Deep Library only when needed. The OS ZIP is CONTROL, not article subject matter, unless the user explicitly makes the OS the topic. Default user-facing language is Korean unless another output language is explicitly requested.

## Historical documents
Past audit/release/change logs live under `ARCHIVE/RELEASE_HISTORY/` and are informational only. They do not override V6.1 active rules.
