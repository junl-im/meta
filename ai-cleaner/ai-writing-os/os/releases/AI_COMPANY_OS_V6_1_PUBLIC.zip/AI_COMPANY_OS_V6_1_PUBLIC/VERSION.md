# VERSION
AI COMPANY OS V6.1 ZIP-ONLY FAST PATH

- Portable ZIP-first runtime
- No Obsidian required
- Root-level Fast Path
- Korean-default output
- OS-as-control / topic-as-content hard boundary
- Above-average default staffing
- BLOG Creator-10 default (explicit QUICK may downshift)
- Instagram Creator-10 + broad-request 3-set default
- YouTube/Shorts 8+ default
- Enterprise 30~80+ / explicit Product-120 100~140+
- Honest persistence and capability boundaries
