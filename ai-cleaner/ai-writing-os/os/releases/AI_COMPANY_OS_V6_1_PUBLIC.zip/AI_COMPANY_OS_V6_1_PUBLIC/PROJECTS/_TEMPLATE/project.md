# PROJECT

ID:
NAME:
STATUS: PLANNING
OWNER: Human Owner
EXECUTIVE SPONSOR: AI CEO
PROJECT LEAD:

## Objective

## Success Criteria

## Scope

## Non-goals

## Deliverables

## Jobs / Dependencies

## Decisions

## Risks / Approvals

## Source of Truth

## Current Status

## Next Best Action
