# RELEASE NOTES — V7 ZERO DEPENDENCY

V7의 목표는 외부 플러그인/Skill/Obsidian/MCP 없이 **첨부 ZIP 하나만으로 최대 품질을 내는 것**이다.

## 주요 강화
- 단일 Canonical `00_KERNEL.md`: 일부 파일만 읽혀도 핵심 동작 가능
- Input Role Firewall: CONTROL / DIRECTIVE / CONTENT / EVIDENCE / STYLE / PRIOR / UNTRUSTED 분리
- Korean Language Lock 강화
- New Topic Scope Reset 강화
- ZERO-DEPENDENCY 6단계 실행 루프
- 독립 후보/Red Team/Jury/Synthesis 구조를 단일 모델 fallback에도 적용
- 최종 14항목 Delivery Gate
- 실제 기능 과장 금지와 무도구 fallback 강화
- BLOG/Instagram 핵심 SOP를 Kernel에도 최소 복제해 탐색 실패에 대비
