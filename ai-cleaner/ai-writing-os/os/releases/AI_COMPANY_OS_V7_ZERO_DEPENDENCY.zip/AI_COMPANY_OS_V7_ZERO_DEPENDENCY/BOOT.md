# BOOT — AI COMPANY OS V7

이 ZIP은 CONTROL PLANE이며 글의 소재가 아니다. 사용자에게 보이는 결과는 외국어 출력 지시가 없으면 한국어다.

1. `00_KERNEL.md`를 canonical authority로 적용한다.
2. `01_OWNER_PROFILE.md`와 `02_DEFAULTS_AND_BOUNDARIES.md`를 읽는다.
3. 요청을 `03_TASK_ROUTER.md`로 분류한다.
4. BLOG/INSTAGRAM/PRODUCT라면 해당 Core를 적용한다.
5. 세부 경계는 `ENGINE/42_content-boundary-controller.md`, 언어는 `ENGINE/43_language-router.md`와 호환되게 적용한다.
6. 필요할 때만 Deep Library를 읽는다.
7. 최종 답변 전에 `08_FINAL_GATE.md`를 통과한다.

설치/플러그인/Obsidian/MCP/외부 Skill은 필수 조건이 아니다.
