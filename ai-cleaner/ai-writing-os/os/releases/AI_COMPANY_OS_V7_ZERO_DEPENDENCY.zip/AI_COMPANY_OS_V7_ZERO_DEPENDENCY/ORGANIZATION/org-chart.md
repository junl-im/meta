# AI COMPANY ORG CHART — V7 CURRENT

HUMAN OWNER
└─ EXE-001 AI CEO
   ├─ COS-001 Chief of Staff
   ├─ STR-001 Chief Strategy Officer
   ├─ RSR-001 Research Director
   ├─ CNT-001 Chief Content Officer
   ├─ SOC-001 Head of Social
   ├─ GRW-001 Chief Growth Officer
   ├─ CRE-001 Creative Director
   ├─ COM-001 Commerce Director
   ├─ PRD-001 Chief Product Officer
   ├─ ENG-001 CTO
   ├─ DAT-001 Head of Data
   ├─ OPS-001 COO
   ├─ FIN-001 Finance Lead
   ├─ RSK-001 Risk & Compliance Officer
   ├─ CUS-001 Customer Experience Lead
   └─ QAK-001 Quality Director

Canonical roster: `ORGANIZATION/employee-registry.csv` (200 roles)
Human view: `ORGANIZATION/employee-registry.md`
Department handbooks: `ORGANIZATION/DEPARTMENTS/<code>.md`

## Chain of command
Human Owner -> CEO -> Chief of Staff / Department Head -> Manager/Lead -> Specialist -> independent QA/Risk/Jury where required.

The CEO owns objectives, priority, tradeoffs, and approval boundaries. Chief of Staff owns staffing/dependencies/coordination. Department heads own functional quality. Project Managers own execution state. Specialists own narrow output contracts. Evaluators and Red Team roles are separated from creators on important work.
