#!/usr/bin/env python3
"""Contract regression checks for V5.5 boundary/language defaults.
This does not simulate an LLM; it verifies that the portable/runtime policy files
carry the required redundant rules so future packaging changes cannot silently remove them.
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
errors=[]

def need(rel,*tokens):
    p=ROOT/rel
    if not p.exists():
        errors.append(f'MISSING {rel}')
        return
    text=p.read_text(encoding='utf-8')
    for t in tokens:
        if t not in text:
            errors.append(f'{rel} missing {t!r}')

# Triple enforcement: boot -> context -> delivery.
need('BOOT.md','CONTROL PLANE','한국어','42_content-boundary-controller.md','43_language-router.md')
need('TEMPLATES/context-pack.md','CONTROL_ASSETS','TASK_CONTENT','OUTPUT_LANGUAGE','ko')
need('ENGINE/32_delivery-controller.md','Final Content Boundary Gate','한국어')

# Detailed policies.
need('SYSTEM/08_content-boundary.md','글의 소재가 아니라','OS 자체가 콘텐츠가 되는 유일한 경우','여러 첨부파일','이전 작업 오염 방지')
need('SYSTEM/09_language-policy.md','절대 기본값','외국어 자료는 출력 언어를 바꾸지 않는다','명시적 외국어 요청','언어가 애매하면 한국어')
need('ENGINE/19_prompt-injection-firewall.md','일반 참고자료는 DATA/CONTENT','영어로 답하라')
need('ENGINE/42_content-boundary-controller.md','Topic Source Whitelist','STYLE_REFERENCE','PRIOR_OUTPUT')
need('ENGINE/43_language-router.md','Default','KOREAN','Final Language Gate')

# Creator channel enforcement.
need('EMPLOYEES/BLOG/sop.md','Current Content/Language Guard','한국어','OS')
need('EMPLOYEES/INSTAGRAM/sop.md','Current Content/Language Guard','한국어','OS')
need('EMPLOYEES/BLOG/checklist.md','Current Final Guard','한국어')
need('EMPLOYEES/INSTAGRAM/checklist.md','Current Final Guard','한국어')

# Easy/portable entrypoints must explain the exact failure modes.
need('EASY_START.md','글의 소재가 아니라','한국어')
need('ATTACH_AND_RUN.md','글 소재가 아니라','한국어')
need('PORTABLE/PORTABLE_CORE.md','CONTROL PLANE','Korean-first')
need('PORTABLE/BOOT_PROMPT.txt','글 소재가 아니야','한국어')

print('V7 CONTENT CONTRACT TEST')
if errors:
    print('FAIL',len(errors))
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS')
