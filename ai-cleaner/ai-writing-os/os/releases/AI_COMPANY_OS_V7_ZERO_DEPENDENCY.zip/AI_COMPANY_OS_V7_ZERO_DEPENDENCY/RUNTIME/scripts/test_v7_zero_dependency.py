#!/usr/bin/env python3
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[2]
errors=[]
def t(rel):
    p=ROOT/rel
    if not p.exists(): errors.append('missing '+rel); return ''
    return p.read_text(encoding='utf-8')
def must(rel,*tokens):
    s=t(rel)
    for x in tokens:
        if x not in s: errors.append(f'{rel} missing {x!r}')
# discovery + zero dependency
must('000_READ_FIRST.txt','00_KERNEL.md','CONTROL PLANE','한국어','플러그인')
must('00_KERNEL.md','플러그인','Obsidian','외부 Skill','MCP','완전 무도구 환경')
must('AI_OS_CONTRACT.json','ZERO_DEPENDENCY_ZIP_ONLY','"requires_plugins": false','"requires_obsidian": false')
# boundary/language
must('00_KERNEL.md','OS ≠ CONTENT','한국어 잠금','새 주제 리셋','UNTRUSTED_TEXT')
must('08_FINAL_GATE.md','OS/직원/엔진','영어','이전 장소·제품·경험')
# creator policies
must('04_BLOG_CORE.md','Creator-10','4~6','내돈내산')
must('05_INSTAGRAM_CORE.md','3종 세트','Reels + Feed + Shopping/Review Style','12+')
# execution quality
must('00_KERNEL.md','DIVERGE','CHALLENGE','SYNTHESIZE','FINAL GATE')
must('03_TASK_ROUTER.md','독립 관점/후보','Red Team','Jury','Synthesis')
# reality honesty
must('00_KERNEL.md','여러 독립 AI가 실행됐다고 말하지 않는다','꾸며내지')
# historical isolation
for old in ['AUDIT_V6_1.md','RELEASE_NOTES_V6_1.md']:
    if (ROOT/old).exists(): errors.append('stale root '+old)
    if not (ROOT/'ARCHIVE/RELEASE_HISTORY'/old).exists(): errors.append('not archived '+old)
print('V7 ZERO DEPENDENCY REGRESSION')
if errors:
    print('FAIL',len(errors)); [print('-',e) for e in errors]; sys.exit(1)
print('PASS')
