#!/usr/bin/env python3
from pathlib import Path
import csv, json, re, sys, collections
ROOT=Path(__file__).resolve().parents[2]
errors=[]; warnings=[]
def err(x): errors.append(x)
def warn(x): warnings.append(x)
def need(rel,*tokens):
    p=ROOT/rel
    if not p.exists(): err(f'MISSING {rel}'); return
    s=p.read_text(encoding='utf-8')
    for t in tokens:
        if t not in s: err(f'{rel} missing {t!r}')
required=[
'000_READ_FIRST.txt','OS_IDENTITY.json','AI_OS_CONTRACT.json','00_KERNEL.md','00_OPEN_FIRST.md','01_OWNER_PROFILE.md','02_DEFAULTS_AND_BOUNDARIES.md','03_TASK_ROUTER.md','04_BLOG_CORE.md','05_INSTAGRAM_CORE.md','06_PRODUCT_ENTERPRISE_CORE.md','07_STATE_AND_UPDATE.md','08_FINAL_GATE.md','09_SESSION_STATE.md','QUICK_COMMANDS.md','BOOT.md','START_HERE.md','VERSION.md','MANIFEST.md','PORTABLE/PORTABLE_CORE.md',
'ORGANIZATION/employee-registry.csv','ORGANIZATION/department-registry.md','ORGANIZATION/org-chart.md','RUNTIME/tool-profiles.md','RUNTIME/00_capability-probe.md','RUNTIME/reality-ladder.md','SKILLS/skill-registry.csv','ENGINE/20_role-instantiator.md','ENGINE/22_action-gate.md','ENGINE/28_context-packager.md','ENGINE/33_deliberation-controller.md','ENGINE/38_quality-floor-router.md','ENGINE/39_marginal-value-controller.md','ENGINE/40_diversity-controller.md','ENGINE/41_checkpoint-controller.md','ENGINE/42_content-boundary-controller.md','ENGINE/43_language-router.md','SYSTEM/08_content-boundary.md','SYSTEM/09_language-policy.md','DELIBERATION/blog-10-playbook.md','DELIBERATION/instagram-10-playbook.md','DELIBERATION/product-120-playbook.md','EMPLOYEES/BLOG/sop.md','EMPLOYEES/BLOG/checklist.md','EMPLOYEES/INSTAGRAM/sop.md','EMPLOYEES/INSTAGRAM/checklist.md','GOVERNANCE/reasoning-privacy.md','RECOVERY/recovery-policy.md','SCHEMAS/context-pack.schema.json','SCHEMAS/input-asset.schema.json','RUNTIME/scripts/test_content_contract.py','RUNTIME/scripts/test_v7_zero_dependency.py','TESTS/V7_ZERO_DEPENDENCY_TESTS.md','TESTS/CROSS_MODEL_ACCEPTANCE.md']
for r in required:
    if not (ROOT/r).exists(): err(f'MISSING required file: {r}')
# identities
for rel in ['OS_IDENTITY.json','AI_OS_CONTRACT.json']:
    try: obj=json.loads((ROOT/rel).read_text(encoding='utf-8'))
    except Exception as e: err(f'INVALID {rel}: {e}'); continue
    if obj.get('version')!='7.0': err(f'{rel} version != 7.0')
    if obj.get('role')!='CONTROL_PLANE': err(f'{rel} role != CONTROL_PLANE')
if (ROOT/'AI_OS_CONTRACT.json').exists():
    obj=json.loads((ROOT/'AI_OS_CONTRACT.json').read_text(encoding='utf-8'))
    for k in ['requires_plugins','requires_external_skills','requires_obsidian','requires_mcp']:
        if obj.get(k) is not False: err(f'zero-dependency contract violated: {k}')
# employees
employees=[]
try:
    with (ROOT/'ORGANIZATION/employee-registry.csv').open(encoding='utf-8-sig',newline='') as f: employees=list(csv.DictReader(f))
    ids=[r.get('employee_id','') for r in employees]
    if len(ids)!=len(set(ids)): err('DUPLICATE employee_id')
    if len(ids)<200: err(f'employee registry below 200: {len(ids)}')
    emp_ids=set(ids)
    for r in employees:
        rt=(r.get('reports_to') or '').strip()
        if r.get('employee_id')=='EXE-001':
            if rt!='HUMAN_OWNER': err('EXE-001 must report to HUMAN_OWNER')
        elif not rt or rt not in emp_ids: err(f"INVALID reports_to: {r.get('employee_id')} -> {rt}")
        if rt==r.get('employee_id'): err(f"SELF report: {r.get('employee_id')}")
except Exception as e: err(f'employee registry error: {e}')
# skills
skill_rows=[]
try:
    with (ROOT/'SKILLS/skill-registry.csv').open(encoding='utf-8-sig',newline='') as f: skill_rows=list(csv.DictReader(f))
    sids=[r.get('skill_id','') for r in skill_rows]
    if len(sids)!=len(set(sids)): err('DUPLICATE skill_id')
    if len(sids)<90: err(f'skill registry unexpectedly small: {len(sids)}')
    skill_ids=set(sids)
    for sid in sids:
        if not (ROOT/'SKILLS/library'/sid/'SKILL.md').exists(): err(f'MISSING skill file: {sid}')
    for r in employees:
        for sid in [x.strip() for x in re.split(r'[;,|]',r.get('default_skills','')) if x.strip()]:
            if sid not in skill_ids: err(f"UNRESOLVED employee skill: {r.get('employee_id')} -> {sid}")
except Exception as e: err(f'skill registry error: {e}')
# departments
codes=sorted(set(r.get('dept_code','') for r in employees if r.get('dept_code')))
for code in codes:
    if not (ROOT/'ORGANIZATION/DEPARTMENTS'/f'{code}.md').exists(): err(f'MISSING department handbook: {code}')
# tool profiles
profile_text=(ROOT/'RUNTIME/tool-profiles.md').read_text(encoding='utf-8') if (ROOT/'RUNTIME/tool-profiles.md').exists() else ''
for prof in sorted(set(r.get('tool_profile','') for r in employees)):
    if prof and prof not in profile_text: err(f'UNDEFINED tool_profile: {prof}')
# engines
nums=collections.defaultdict(list)
for p in (ROOT/'ENGINE').glob('*.md'):
    m=re.match(r'(\d+)_',p.name)
    if m: nums[m.group(1)].append(p.name)
for n,names in nums.items():
    if len(names)>1: err(f'DUPLICATE engine prefix {n}: {names}')
for i in range(44):
    if f'{i:02d}' not in nums: warn(f'engine prefix gap: {i:02d}')
# schemas
schemas=list((ROOT/'SCHEMAS').glob('*.json'))
for p in schemas:
    try:
        obj=json.loads(p.read_text(encoding='utf-8'))
        try:
            import jsonschema
            jsonschema.Draft202012Validator.check_schema(obj)
        except ImportError: pass
        except Exception as e: err(f'INVALID JSON schema {p.name}: {e}')
    except Exception as e: err(f'INVALID JSON {p.name}: {e}')
# hard contracts
need('000_READ_FIRST.txt','00_KERNEL.md','CONTROL PLANE','한국어','플러그인')
need('00_KERNEL.md','OS ≠ CONTENT','한국어 잠금','UNTRUSTED_TEXT','새 주제 리셋','ZERO-DEPENDENCY 실행 루프','DIVERGE','CHALLENGE','SYNTHESIZE','BLOG 미니 계약','INSTAGRAM 미니 계약','완전 무도구 환경')
need('00_OPEN_FIRST.md','00_KERNEL.md','글 소재가 아니다','한국어')
need('02_DEFAULTS_AND_BOUNDARIES.md','OUTPUT_LANGUAGE: ko','OS_ROLE: CONTROL_ONLY','UNTRUSTED_TEXT','Scope Reset')
need('03_TASK_ROUTER.md','Execution Contract','PRODUCT-120','독립 관점/후보','Red Team','Jury','Synthesis')
need('04_BLOG_CORE.md','4~6','내돈내산','Creator-10','허위')
need('05_INSTAGRAM_CORE.md','3종 세트','Reels + Feed + Shopping/Review Style','12+')
need('06_PRODUCT_ENTERPRISE_CORE.md','30~80+','100~140+','Independent Jury')
need('08_FINAL_GATE.md','14.','OS/직원/엔진','영어','허위','멀티에이전트')
need('BOOT.md','CONTROL PLANE','한국어','00_KERNEL.md','08_FINAL_GATE.md','42_content-boundary-controller.md','43_language-router.md')
need('PORTABLE/PORTABLE_CORE.md','V7','CONTROL PLANE','Korean-first','100-140','내돈내산')
need('EMPLOYEES/BLOG/sop.md','4~6','내돈내산','허위','자연스러움')
need('EMPLOYEES/INSTAGRAM/sop.md','3종','REELS','FEED','한국어')
need('SYSTEM/08_content-boundary.md','CONTROL PLANE','CONTENT PLANE','소재가 아니다')
need('SYSTEM/09_language-policy.md','한국어','외국어 자료','명시')
# known contradiction guards
for rel in ['CEO.md','ENGINE/01_intent-detector.md']:
    p=ROOT/rel
    if p.exists() and '필요한 세트를 판단' in p.read_text(encoding='utf-8'): err(f'stale Instagram routing phrase: {rel}')
# stale root historical docs
for old in ['AUDIT_V6_1.md','RELEASE_NOTES_V6_1.md','AUDIT_V5_5.md','RELEASE_NOTES_V5_5.md','PRODUCTION_AUDIT.md','REALITY_AUDIT.md']:
    if (ROOT/old).exists(): err(f'HISTORICAL control doc left at root: {old}')
# active entrypoints version
for rel in ['000_READ_FIRST.txt','00_KERNEL.md','00_OPEN_FIRST.md','BOOT.md','START_HERE.md','PORTABLE/PORTABLE_CORE.md','VERSION.md']:
    p=ROOT/rel
    if p.exists() and 'V7' not in p.read_text(encoding='utf-8'): warn(f'V7 label missing: {rel}')
print('AI COMPANY OS V7 ZERO-DEPENDENCY VALIDATION')
print('root:',ROOT)
print('employees:',len(employees),'skills:',len(skill_rows),'departments:',len(codes),'engines:',len(nums),'schemas:',len(schemas))
if warnings:
    print('WARNINGS:',len(warnings)); [print('-',w) for w in warnings]
if errors:
    print('FAIL:',len(errors)); [print('-',e) for e in errors]; sys.exit(1)
print('PASS')
