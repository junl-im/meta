# MANIFEST — AI COMPANY OS V7 ZERO DEPENDENCY ZIP-ONLY

## Integrity summary
- registered employees: 200
- registered skills: 99
- department handbooks: 17
- engine modules: 44
- schemas: 8
- total files: 355
- total directories: 159

## Tier 0 — Canonical Kernel / Fast Path
- `000_READ_FIRST.txt` — ultra-compact plain-text discovery entry
- `AI_OS_CONTRACT.json` — machine-readable zero-dependency contract
- `OS_IDENTITY.json` — package identity/version
- `00_KERNEL.md` — canonical single-file operating kernel
- `00_OPEN_FIRST.md` — discovery fallback
- `01_OWNER_PROFILE.md` — condensed owner preferences
- `02_DEFAULTS_AND_BOUNDARIES.md` — input firewall / Korean / scope defaults
- `03_TASK_ROUTER.md` — natural-language routing + execution contract
- `04_BLOG_CORE.md` — Naver Blog Creator-10 core
- `05_INSTAGRAM_CORE.md` — Instagram Creator-10+ core
- `06_PRODUCT_ENTERPRISE_CORE.md` — product / enterprise staged review
- `07_STATE_AND_UPDATE.md` — honest persistence/update rules
- `08_FINAL_GATE.md` — final 14-check delivery gate
- `09_SESSION_STATE.md` — same-chat/new-chat state behavior
- `PORTABLE/PORTABLE_CORE.md` — single-file fallback

## Tier 1 — Deep governance
`SYSTEM/`, `GOVERNANCE/`, `RUNTIME/`, `REALITY_PRINCIPLES.md`

## Tier 2 — Company / execution
`EXECUTIVE/`, `ORGANIZATION/`, `ENGINE/`, `STAFF/CORE/`, `SKILLS/`

## Tier 3 — Deep creator contracts
`EMPLOYEES/BLOG/`, `EMPLOYEES/INSTAGRAM/`, `DELIBERATION/`

## Tier 4 — State / operations
`PROJECTS/`, `PROJECTS_ACTIVE/`, `JOBS/`, `QUEUE/`, `MEMORY/`, `KNOWLEDGE/`, `LEDGERS/`, `AUDIT/`, `OUTPUT/`

## Tier 5 — Reliability
`EVALS/`, `TESTS/`, `RECOVERY/`, `OBSERVABILITY/`, `SCHEMAS/`, `RUNTIME/scripts/`

## Mandatory load policy
Start at `00_KERNEL.md`. If the runtime only discovers `00_OPEN_FIRST.md`, it redirects to the Kernel and repeats the five hard invariants. Deep Library is optional precision, not a dependency. The OS is CONTROL, not content, unless the user explicitly makes the OS the topic. Default user-facing language is Korean unless another language is explicitly requested.

## Historical isolation
Past release/audit/test documents under `ARCHIVE/` are informational only and have no execution authority.
