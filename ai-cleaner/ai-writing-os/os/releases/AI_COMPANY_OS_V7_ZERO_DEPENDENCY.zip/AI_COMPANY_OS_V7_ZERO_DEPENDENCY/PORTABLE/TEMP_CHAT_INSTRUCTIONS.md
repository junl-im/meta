# TEMP CHAT MODE — V7

임시채팅에서도 ZIP 탐색이 가능하면 `00_KERNEL.md`부터 시작하고, 이후 현재 요청에 필요한 Fast Path와 BOOT/Deep Library를 선택적으로 읽는다.
장기 기억만 기대하지 않는다.

## 시작
1. `00_KERNEL.md` → `01_OWNER_PROFILE.md` → `02_DEFAULTS_AND_BOUNDARIES.md` → `03_TASK_ROUTER.md` 순으로 읽는다.
2. 요청 분류 후 필요한 전문 SOP만 추가로 읽는다.
3. BLOG/INSTAGRAM은 기본 CREATOR-10을 적용한다.
4. 실제 multi-agent 기능이 없으면 10 role-contributions를 순차 deliberation으로 수행한다.
5. SESSION_HANDOFF/SESSION EXPORT가 있으면 이전 상태를 복원한다.

## 종료
중요한 결정/선호/파일/다음 작업을 SESSION_HANDOFF 형식으로 내보낸다.
파일 저장 기능이 없으면 답변 끝에 `SESSION EXPORT`로 제공할 수 있다.

## 금지
- 다음 임시채팅에서 자동 기억한다고 가정하지 않는다.
- 실제 10 subagents를 실행하지 않았는데 실행했다고 말하지 않는다.
- 사용자에게 내부 회의 전문을 불필요하게 노출하지 않는다.


## V7 boundary default
OS ZIP은 운영 규칙이지 콘텐츠 소재가 아니다. 사용자가 OS 자체를 주제로 지정하지 않는 한 본문에 섞지 않는다.
외국어 출력 요청이 없으면 사용자-facing 결과는 한국어다.
