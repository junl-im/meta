# AI COMPANY OS V7 — ZERO DEPENDENCY AUDIT

## 목표
외부 플러그인, Obsidian, MCP, 별도 ChatGPT/Claude Skill 설치 없이 **ZIP 첨부 하나만으로 최대한 안정적으로 작동**하는 AI Company OS.

## V7 핵심 강화
1. `000_READ_FIRST.txt` — Markdown 탐색이 약한 환경을 위한 plain-text discovery.
2. `00_KERNEL.md` — 한 파일만 읽혀도 핵심 개인화/경계/언어/품질/Creator 규칙이 살아나는 canonical kernel.
3. `AI_OS_CONTRACT.json` — zero-dependency 조건을 machine-readable로 고정.
4. Input Role Firewall — CONTROL / USER_DIRECTIVE / TASK_CONTENT / EVIDENCE / STYLE_REFERENCE / PRIOR_OUTPUT / UNTRUSTED_TEXT 분리.
5. Korean Language Lock — 외국어 출력 요청 전까지 한국어.
6. New Topic Reset — 새 주제가 이전 제품/장소/경험에 오염되는 문제 차단.
7. ZERO-DEPENDENCY 6단계 실행 루프 — CONTRACT → ROUTE → DIVERGE → CHALLENGE → SYNTHESIZE → FINAL GATE.
8. `08_FINAL_GATE.md` — 14개 최종 납품 검사.
9. BLOG Creator-10, Instagram 10+/3종, Product/Enterprise 15~140+ 정책 유지.
10. 실제 멀티에이전트/웹/파일쓰기 기능을 사용하지 않았는데 사용했다고 주장하는 것을 금지.
11. 구버전 릴리스/테스트 문서를 ARCHIVE로 격리하여 규칙 충돌 가능성 축소.
12. CEO/Intent 라우터까지 Instagram 포괄 요청 = Reels + Feed + Shopping/Review 3종으로 통일.

## 현재 패키지 규모
- total files: 355
- total directories: 159
- registered employees: 200
- registered skills: 99
- departments: 17
- engines: 44
- schemas: 8

## 무결성 검사 항목
- Employee ID 중복 / reports_to 유효성
- Skill ID 중복 / 직원 Skill 참조 / Skill 파일 존재
- Department handbook 존재
- Tool profile 참조
- Engine prefix 00–43 구조
- JSON Schema parse/meta validation
- Kernel / language / content boundary / creator contract
- 과거 실행문서 root 격리
- ZIP CRC / 재압축 후 재해제 테스트

## 현실적 한계
이 ZIP 자체가 모델 실행 엔진은 아니다. 호스트 AI가 ZIP 내부 파일을 읽을 수 있어야 한다. 호스트가 ZIP을 전혀 탐색하지 못하면 어떤 ZIP-only OS도 자동 적용할 수 없다. 다만 ZIP을 읽을 수 있는 환경에서는 V7 Kernel이 Deep Library 전체를 읽지 않아도 주요 규칙을 복원하도록 설계했다.

멀티에이전트가 없는 AI에서는 Creator-10/100+를 실제 병렬 에이전트 수로 가장하지 않고, 역할 분리된 독립 후보·비판·평가·합성 기여로 수행한다.

## 사용법
ZIP 첨부 후:
`이건 내 가상 OS야. 이걸 기준으로 해줘.`

또는 바로:
`이건 내 가상 OS야. 이 사진과 키워드로 블로그 써줘.`
